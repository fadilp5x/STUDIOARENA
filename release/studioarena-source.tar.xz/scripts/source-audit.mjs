import fs from "node:fs";
import path from "node:path";
import process from "node:process";

const root = process.cwd();
const failures = [];
const read = (name) => fs.readFileSync(path.join(root, name), "utf8");

function assert(condition, message) {
  if (!condition) failures.push(message);
}

const trackedLikeFiles = [];
function walk(dir) {
  for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
    if (["node_modules", ".next", ".git", "coverage", "build"].includes(entry.name)) continue;
    const absolute = path.join(dir, entry.name);
    if (entry.isDirectory()) walk(absolute);
    else if (entry.isFile()) trackedLikeFiles.push(path.relative(root, absolute));
  }
}
walk(root);

assert(fs.existsSync(path.join(root, ".env.example")), ".env.example is missing");
assert(!fs.existsSync(path.join(root, ".env")), "A real .env file must never be included in the source snapshot");
assert(read(".gitignore").includes(".env"), ".gitignore must exclude local environment files");
assert(read(".gitignore").includes("node_modules/"), ".gitignore must exclude node_modules");
assert(read("README.md").includes("GPT-6 by OpenAI"), "README must identify the AI model");
assert(read("README.md").includes("Implementation agent"), "README must identify the implementation agent");
assert(read("app/api/uploads/route.ts").includes("uploadMedia(file"), "Uploads must go through the YourImageShare adapter");
assert(read("models/index.ts").includes("storageConnectionId"), "Asset metadata must retain its media storage connection reference");
assert(!/Buffer|GridFS|BinData|data:\s*Buffer/i.test(read("models/index.ts")), "Mongo models must not define media binary storage fields");
assert(read("lib/crypto.ts").includes("aes-256-gcm"), "Saved API credentials must use authenticated encryption");
assert(read("app/api/connections/route.ts").includes("encryptSecret(input.apiKey)"), "Provider keys must be encrypted before persistence");
assert(read("app/api/uploads/route.ts").includes("storageConnectionId"), "Uploaded files must be linked to the key that owns them");
assert(read("app/api/generations/route.ts").includes("output_format"), "Seedance output format must be wired through the backend");
assert(read("app/api/generations/route.ts").includes("service_tier"), "Seedance service tier must be wired through the backend");
assert(read("components/studio-app.tsx").includes("generation-preview-card"), "The Studio chat must render generation previews");

// Scan source and documentation for obvious live API-key literals. Placeholders are allowed.
const sourceFiles = trackedLikeFiles.filter((file) => /\.(?:ts|tsx|js|mjs|json|md|yml|yaml|css|env\.example)$/.test(file));
for (const file of sourceFiles) {
  const content = read(file);
  const suspicious = [
    /sk-[A-Za-z0-9]{20,}/,
    /AIza[0-9A-Za-z_-]{30,}/,
    /xox[baprs]-[A-Za-z0-9-]{15,}/,
    /Bearer\s+(?!YOUR_|REPLACE_|<)[A-Za-z0-9._~-]{24,}/i,
  ];
  if (suspicious.some((pattern) => pattern.test(content))) failures.push(`Potential credential literal found in ${file}`);
}

if (failures.length) {
  console.error("StudioArena source audit failed:");
  for (const failure of failures) console.error(`- ${failure}`);
  process.exit(1);
}

console.log(`StudioArena source audit passed (${sourceFiles.length} source/documentation files checked).`);
console.log("Media binaries stay external; MongoDB schemas contain references and metadata only.");
console.log("No obvious live provider key patterns were found in the source tree.");
