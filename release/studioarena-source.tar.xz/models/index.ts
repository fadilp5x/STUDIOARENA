import mongoose, { Schema, Types } from "mongoose";

const userSchema = new Schema({
  name: { type: String, required: true, trim: true, maxlength: 80 },
  email: { type: String, required: true, unique: true, lowercase: true, trim: true, index: true },
  passwordHash: { type: String, required: true, select: false },
  seedanceAssetGroupId: { type: String, default: null },
}, { timestamps: true });

const connectionSchema = new Schema({
  userId: { type: Types.ObjectId, required: true, index: true },
  provider: { type: String, enum: ["seedance", "yourimageshare", "custom"], required: true },
  label: { type: String, required: true, trim: true, maxlength: 60 },
  baseUrl: { type: String, required: true },
  secret: {
    ciphertext: { type: String, required: true },
    iv: { type: String, required: true },
    tag: { type: String, required: true },
  },
  lastFour: { type: String, default: "" },
  enabled: { type: Boolean, default: true },
  active: { type: Boolean, default: false },
  isDefault: { type: Boolean, default: false },
  lastTestedAt: { type: Date, default: null },
  connectionStatus: { type: String, enum: ["untested", "connected", "error"], default: "untested" },
  seedanceAssetGroupId: { type: String, default: null },
}, { timestamps: true });
connectionSchema.index({ userId: 1, provider: 1, active: 1 });

const assetSchema = new Schema({
  userId: { type: Types.ObjectId, required: true, index: true },
  projectId: { type: Types.ObjectId, default: null, index: true },
  provider: { type: String, default: "yourimageshare" },
  storageConnectionId: { type: String, default: "env-fallback" },
  seedanceConnectionId: { type: String, default: null },
  externalId: { type: String, required: true },
  seedanceAssetId: { type: String, default: null },
  seedanceStatus: { type: String, default: null },
  type: { type: String, enum: ["image", "video", "audio", "model", "file"], required: true },
  title: { type: String, default: "Untitled asset", maxlength: 90 },
  src: { type: String, required: true },
  thumb: { type: String, default: null },
  direct: { type: String, default: null },
  width: { type: Number, default: null },
  height: { type: Number, default: null },
  size: { type: Number, default: null },
  visibility: { type: String, default: "unlisted" },
  expiresAt: { type: Date, default: null },
}, { timestamps: true });
assetSchema.index({ userId: 1, externalId: 1 }, { unique: true });

const generationSchema = new Schema({
  userId: { type: Types.ObjectId, required: true, index: true },
  conversationId: { type: Types.ObjectId, default: null, index: true },
  projectId: { type: Types.ObjectId, default: null, index: true },
  provider: { type: String, default: "seedance" },
  connectionId: { type: String, default: null },
  remoteTaskId: { type: String, required: true, index: true },
  model: { type: String, required: true },
  mode: { type: String, default: "text-to-video" },
  prompt: { type: String, required: true, maxlength: 12000 },
  status: { type: String, enum: ["queued", "running", "succeeded", "failed", "cancelled", "expired"], default: "queued", index: true },
  videoUrl: { type: String, default: null },
  storedVideoUrl: { type: String, default: null },
  lastFrameUrl: { type: String, default: null },
  storedLastFrameUrl: { type: String, default: null },
  errorMessage: { type: String, default: null },
  resolution: { type: String, default: "720p" },
  ratio: { type: String, default: "16:9" },
  outputFormat: { type: String, enum: ["mp4", "mov"], default: "mp4" },
  serviceTier: { type: String, enum: ["default", "flex"], default: "default" },
  duration: { type: Number, default: 5 },
  frames: { type: Number, default: null },
  generateAudio: { type: Boolean, default: true },
  watermark: { type: Boolean, default: false },
  seed: { type: Number, default: -1 },
  cameraFixed: { type: Boolean, default: false },
  returnLastFrame: { type: Boolean, default: false },
  usage: { type: Schema.Types.Mixed, default: null },
  sourceAssets: [{ type: Types.ObjectId }],
}, { timestamps: true });

generationSchema.index({ userId: 1, createdAt: -1 });

const conversationSchema = new Schema({
  userId: { type: Types.ObjectId, required: true, index: true },
  title: { type: String, default: "New creation", maxlength: 100 },
  messages: [{
    role: { type: String, enum: ["user", "assistant", "system"], required: true },
    content: { type: String, default: "" },
    createdAt: { type: Date, default: Date.now },
    generationId: { type: Types.ObjectId, default: null },
    status: { type: String, default: null },
    attachments: [{ id: String, type: String, name: String, src: String, thumb: String }],
  }],
}, { timestamps: true });

const projectSchema = new Schema({
  userId: { type: Types.ObjectId, required: true, index: true },
  name: { type: String, required: true, trim: true, maxlength: 80 },
  description: { type: String, default: "", maxlength: 300 },
  color: { type: String, default: "#716BFF" },
}, { timestamps: true });

export const User = mongoose.models.User || mongoose.model("User", userSchema);
export const Connection = mongoose.models.Connection || mongoose.model("Connection", connectionSchema);
export const Asset = mongoose.models.Asset || mongoose.model("Asset", assetSchema);
export const Generation = mongoose.models.Generation || mongoose.model("Generation", generationSchema);
export const Conversation = mongoose.models.Conversation || mongoose.model("Conversation", conversationSchema);
export const Project = mongoose.models.Project || mongoose.model("Project", projectSchema);
