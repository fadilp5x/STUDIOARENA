"use client";

import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import type { CSSProperties, FormEvent } from "react";
import {
  Activity, Aperture, ArrowDownToLine, ArrowLeft, ArrowRight, AudioLines, BookOpen,
  Check, CheckCircle2, ChevronDown, ChevronRight, CircleHelp, Clapperboard, Clock3, CloudUpload,
  Command, Film, Folder, FolderOpen, Grid2X2, Image as ImageIcon, KeyRound, LayoutDashboard,
  LoaderCircle, LogIn, LogOut, Menu, MessageSquare, MoreHorizontal, Paperclip, Pause, Play,
  Plus, RefreshCw, Search, Send, Settings2, ShieldCheck, SlidersHorizontal, Sparkles, Trash2,
  Upload, Video, WandSparkles, X, Zap,
} from "lucide-react";

type User = { id: string; name: string; email: string };
type Asset = { id: string; externalId: string; type: string; title: string; src: string; thumb?: string | null; size?: number; seedanceAssetId?: string | null; seedanceStatus?: string | null; seedanceConnectionId?: string | null; role?: "first_frame" | "last_frame" | "reference_image" };
type Connection = { id: string; provider: string; label: string; baseUrl: string; maskedKey: string; active: boolean; isDefault: boolean; connectionStatus: string; enabled: boolean };
type Generation = { id: string; taskId: string; status: string; prompt: string; model: string; mode: string; videoUrl?: string | null; temporaryVideoUrl?: string | null; lastFrameUrl?: string | null; errorMessage?: string | null; createdAt?: string; resolution?: string; ratio?: string; duration?: number };
type ChatMessage = { id: string; role: "user" | "assistant"; content: string; status?: string; attachments?: Asset[]; generation?: Generation };
type Page = "studio" | "assets" | "api" | "projects" | "history" | "settings";
type Project = { id: string; name: string; description?: string; color?: string };

const MODELS = [
  { id: "doubao-seedance-2-0-mini-260615", name: "Seedance 2.0 Mini", provider: "Seedance", description: "Model ID from the supplied API guide" },
];
const NAV: { id: Page; label: string; icon: any }[] = [
  { id: "studio", label: "Studio", icon: LayoutDashboard },
  { id: "assets", label: "Assets", icon: Grid2X2 },
  { id: "api", label: "API Hub", icon: Command },
  { id: "projects", label: "Projects", icon: Folder },
  { id: "history", label: "History", icon: Clock3 },
];

async function api<T = any>(url: string, init?: RequestInit): Promise<T> {
  const response = await fetch(url, { ...init, headers: { ...(init?.body && !(init.body instanceof FormData) ? { "Content-Type": "application/json" } : {}), ...(init?.headers || {}) }, cache: "no-store" });
  const payload = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(payload.error || payload.message || `Request failed (${response.status})`);
  return payload as T;
}

function formatSize(bytes?: number) {
  if (!bytes) return "—";
  if (bytes < 1024 * 1024) return `${Math.round(bytes / 1024)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}
function statusLabel(value?: string) { return (value || "queued").replaceAll("_", " "); }

export default function StudioApp() {
  const [user, setUser] = useState<User | null>(null);
  const [authLoading, setAuthLoading] = useState(true);
  const [page, setPage] = useState<Page>("studio");
  const [mobileMenu, setMobileMenu] = useState(false);
  const [toast, setToast] = useState("");
  const [assets, setAssets] = useState<Asset[]>([]);
  const [connections, setConnections] = useState<Connection[]>([]);
  const [generations, setGenerations] = useState<Generation[]>([]);
  const [projects, setProjects] = useState<Project[]>([]);
  const [chatMessages, setChatMessages] = useState<ChatMessage[]>([]);
  const [prompt, setPrompt] = useState("");
  const [mode, setMode] = useState("text-to-video");
  const [model, setModel] = useState(MODELS[0].id);
  const [resolution, setResolution] = useState("720p");
  const [ratio, setRatio] = useState("16:9");
  const [duration, setDuration] = useState(5);
  const [durationMode, setDurationMode] = useState<"duration" | "frames">("duration");
  const [frames, setFrames] = useState(120);
  const [outputFormat, setOutputFormat] = useState<"mp4" | "mov">("mp4");
  const [serviceTier, setServiceTier] = useState<"default" | "flex">("default");
  const [selectedProjectId, setSelectedProjectId] = useState("");
  const [audio, setAudio] = useState(true);
  const [watermark, setWatermark] = useState(false);
  const [cameraFixed, setCameraFixed] = useState(false);
  const [lastFrame, setLastFrame] = useState(false);
  const [seed, setSeed] = useState("-1");
  const [advanced, setAdvanced] = useState(false);
  const [attached, setAttached] = useState<Asset[]>([]);
  const [audioReferenceUrl, setAudioReferenceUrl] = useState("");
  const [conversationId, setConversationId] = useState<string | null>(null);
  const [uploading, setUploading] = useState(false);
  const [generating, setGenerating] = useState(false);
  const [activeGenerationId, setActiveGenerationId] = useState<string | null>(null);
  const [authMode, setAuthMode] = useState<"login" | "register">("login");
  const [authForm, setAuthForm] = useState({ name: "", email: "", password: "" });
  const [authError, setAuthError] = useState("");
  const [connectionForm, setConnectionForm] = useState({ provider: "seedance", label: "Seedance Production", baseUrl: "https://open.fast-api.org", apiKey: "", makeActive: true });
  const [showConnectionForm, setShowConnectionForm] = useState(false);
  const [projectName, setProjectName] = useState("");
  const [projectDescription, setProjectDescription] = useState("");
  const [busyAction, setBusyAction] = useState("");
  const [searchText, setSearchText] = useState("");
  const [userMenu, setUserMenu] = useState(false);
  const fileRef = useRef<HTMLInputElement>(null);
  const promptRef = useRef<HTMLTextAreaElement>(null);

  const notify = useCallback((message: string) => {
    setToast(message);
    window.setTimeout(() => setToast(""), 3600);
  }, []);

  const loadWorkspace = useCallback(async () => {
    const [assetData, connectionData, generationData, projectData, conversationsData] = await Promise.all([
      api<{ assets: Asset[] }>("/api/uploads"),
      api<{ connections: Connection[] }>("/api/connections"),
      api<{ generations: Generation[] }>("/api/generations"),
      api<{ projects: Project[] }>("/api/projects"),
      api<{ conversations: any[] }>("/api/conversations"),
    ]);
    setAssets(assetData.assets || []);
    setConnections(connectionData.connections || []);
    setGenerations(generationData.generations || []);
    setProjects(projectData.projects || []);
    const latestConversation = conversationsData.conversations?.[0];
    if (latestConversation) {
      setConversationId(latestConversation.id);
      const restoredMessages = (latestConversation.messages || []).map((message: any) => ({
        id: message.id, role: message.role, content: message.content, status: message.status,
        attachments: (message.attachments || []).map((attachment: any) => ({ id: attachment.id, type: attachment.type, title: attachment.name, src: attachment.src, thumb: attachment.thumb })),
        generation: message.generation || undefined,
      }));
      setChatMessages(restoredMessages);
      const pending = restoredMessages.find((message: ChatMessage) => message.generation && ["queued", "running"].includes(message.generation.status));
      setActiveGenerationId(pending?.generation?.id || null);
      setGenerating(Boolean(pending));
    } else { setChatMessages([]); setConversationId(null); setActiveGenerationId(null); setGenerating(false); }
  }, []);

  useEffect(() => {
    api<{ user: User }>("/api/auth/me").then(({ user: current }) => {
      setUser(current);
      return loadWorkspace();
    }).catch(() => setUser(null)).finally(() => setAuthLoading(false));
  }, [loadWorkspace]);

  useEffect(() => {
    if (!activeGenerationId || !user) return;
    let stopped = false;
    const tick = async () => {
      try {
        const result = await api<{ generation: Generation }>(`/api/generations/${activeGenerationId}`);
        if (stopped) return;
        const next = result.generation;
        setGenerations(items => [next, ...items.filter(item => item.id !== next.id)]);
        setChatMessages(items => items.map(message => message.generation?.id === next.id
          ? { ...message, content: next.status === "succeeded" ? "Your video is ready. Preview it here or download the archived file." : next.status === "failed" ? next.errorMessage || "Generation failed." : `Generation ${statusLabel(next.status)}…`, status: next.status, generation: next }
          : message));
        if (["succeeded", "failed", "expired", "cancelled"].includes(next.status)) {
          setActiveGenerationId(null);
          setGenerating(false);
          if (next.status === "succeeded") notify("Generation complete · video preview is ready");
          else notify(`Generation ${next.status}`);
        }
      } catch (error) {
        if (!stopped) notify(error instanceof Error ? error.message : "Could not refresh task");
      }
    };
    tick();
    const timer = window.setInterval(tick, 6000);
    return () => { stopped = true; window.clearInterval(timer); };
  }, [activeGenerationId, user, notify]);

  const handleAuth = async (event: FormEvent) => {
    event.preventDefault(); setAuthError(""); setBusyAction("auth");
    try {
      const endpoint = authMode === "login" ? "/api/auth/login" : "/api/auth/register";
      const result = await api<{ user: User }>(endpoint, { method: "POST", body: JSON.stringify(authForm) });
      setUser(result.user); await loadWorkspace();
    } catch (error) { setAuthError(error instanceof Error ? error.message : "Authentication failed"); }
    finally { setBusyAction(""); }
  };

  const uploadFiles = async (files: FileList | File[]) => {
    const selected = Array.from(files);
    if (!selected.length) return;
    setUploading(true);
    try {
      const newAssets: Asset[] = [];
      for (const file of selected) {
        const form = new FormData(); form.set("file", file); form.set("title", file.name);
        const result = await api<{ asset: Asset }>("/api/uploads", { method: "POST", body: form });
        newAssets.push(result.asset);
      }
      setAssets(current => [...newAssets, ...current]);
      setAttached(current => [...current, ...newAssets]);
      notify(`${newAssets.length} asset${newAssets.length > 1 ? "s" : ""} uploaded to YourImageShare`);
    } catch (error) { notify(error instanceof Error ? error.message : "Upload failed"); }
    finally { setUploading(false); if (fileRef.current) fileRef.current.value = ""; }
  };

  const generate = async () => {
    if (prompt.trim().length < 3) { notify("Add a prompt before generating"); return; }
    setGenerating(true); setBusyAction("generate");
    try {
      const body = {
        prompt: prompt.trim(), model, mode, assetIds: attached.map(a => a.id), assetRoles: Object.fromEntries(attached.filter(a => a.type === "image").map(a => [a.id, a.role || (mode === "image-to-video" ? "first_frame" : "reference_image")])), projectId: selectedProjectId || undefined, audioReferenceUrl: audioReferenceUrl.trim(), conversationId: conversationId || undefined, resolution, ratio, duration: durationMode === "duration" ? duration : undefined, frames: durationMode === "frames" ? frames : undefined, outputFormat, serviceTier,
        generateAudio: audio, watermark, cameraFixed, returnLastFrame: lastFrame,
        seed: Number.isFinite(Number(seed)) ? Number(seed) : -1,
      };
      const result = await api<{ generation: { id: string; taskId: string; status: string }; conversationId: string }>("/api/generations", { method: "POST", body: JSON.stringify(body) });
      const item: Generation = { id: result.generation.id, taskId: result.generation.taskId, status: result.generation.status, prompt: prompt.trim(), model, mode };
      setChatMessages(current => [...current, { id: `u-${Date.now()}`, role: "user", content: prompt.trim(), attachments: attached }, { id: `a-${Date.now()}`, role: "assistant", content: "Your generation has been queued.", status: "queued", generation: item }]);
      setGenerations(current => [item, ...current]); setActiveGenerationId(item.id); setConversationId(result.conversationId); setPrompt(""); setAttached([]); setAudioReferenceUrl("");
    } catch (error) { setGenerating(false); notify(error instanceof Error ? error.message : "Could not start generation"); }
    finally { setBusyAction(""); }
  };

  const newSession = async () => {
    try {
      const result = await api<{ conversationId: string }>("/api/conversations", { method: "POST", body: JSON.stringify({ title: "New creation" }) });
      setConversationId(result.conversationId);
      setChatMessages([]);
      setPrompt("");
      setAttached([]);
      setAudioReferenceUrl("");
      notify("New creation thread opened");
    } catch (error) { notify(error instanceof Error ? error.message : "Could not create a new session"); }
  };

  const addConnection = async (event: FormEvent) => {
    event.preventDefault(); setBusyAction("connection");
    try {
      const result = await api<{ connection: Connection }>("/api/connections", { method: "POST", body: JSON.stringify(connectionForm) });
      setConnections(items => [result.connection, ...items]); setConnectionForm(form => ({ ...form, apiKey: "" })); setShowConnectionForm(false);
      notify("Encrypted API connection saved");
    } catch (error) { notify(error instanceof Error ? error.message : "Could not save API key"); }
    finally { setBusyAction(""); }
  };

  const activateConnection = async (connection: Connection) => {
    setBusyAction(connection.id);
    try {
      await api(`/api/connections/${connection.id}`, { method: "PATCH", body: JSON.stringify({ action: "activate" }) });
      setConnections(items => items.map(item => item.provider === connection.provider ? { ...item, active: item.id === connection.id, isDefault: item.id === connection.id } : item));
      notify(`${connection.label} is now active`);
    } catch (error) { notify(error instanceof Error ? error.message : "Could not switch API key"); }
    finally { setBusyAction(""); }
  };

  const testConnection = async (connection: Connection) => {
    setBusyAction(connection.id);
    try {
      const result = await api<{ status: string; message?: string }>(`/api/connections/${connection.id}/test`, { method: "POST" });
      setConnections(items => items.map(item => item.id === connection.id ? { ...item, connectionStatus: result.status } : item));
      notify(result.status === "connected" ? "Connection verified" : result.message || "Adapter needs implementation");
    } catch (error) {
      setConnections(items => items.map(item => item.id === connection.id ? { ...item, connectionStatus: "error" } : item));
      notify(error instanceof Error ? error.message : "Connection test failed");
    } finally { setBusyAction(""); }
  };

  const deleteConnection = async (connection: Connection) => {
    if (!window.confirm(`Delete ${connection.label}?`)) return;
    try { await api(`/api/connections/${connection.id}`, { method: "DELETE" }); setConnections(items => items.filter(item => item.id !== connection.id)); notify("API connection removed"); }
    catch (error) { notify(error instanceof Error ? error.message : "Delete failed"); }
  };

  const syncAsset = async (asset: Asset) => {
    setBusyAction(asset.id);
    try { const result = await api<{ status: string; message?: string; connectionId?: string }>(`/api/uploads/${asset.id}/sync`, { method: "POST" }); setAssets(items => items.map(item => item.id === asset.id ? { ...item, seedanceStatus: result.status, seedanceConnectionId: result.connectionId || item.seedanceConnectionId } : item)); notify(result.message || `Seedance asset status: ${result.status}`); }
    catch (error) { notify(error instanceof Error ? error.message : "Could not register asset"); }
    finally { setBusyAction(""); }
  };

  const deleteAsset = async (asset: Asset) => {
    if (!window.confirm(`Delete ${asset.title} from YourImageShare and this library?`)) return;
    try { await api(`/api/uploads/${asset.id}`, { method: "DELETE" }); setAssets(items => items.filter(item => item.id !== asset.id)); setAttached(items => items.filter(item => item.id !== asset.id)); notify("Asset deleted"); }
    catch (error) { notify(error instanceof Error ? error.message : "Delete failed"); }
  };

  const addProject = async (event: FormEvent) => {
    event.preventDefault();
    try { const result = await api<{ project: Project }>("/api/projects", { method: "POST", body: JSON.stringify({ name: projectName, description: projectDescription }) }); setProjects(items => [result.project, ...items]); setProjectName(""); setProjectDescription(""); notify("Project created"); }
    catch (error) { notify(error instanceof Error ? error.message : "Could not create project"); }
  };

  const logout = async () => { await api("/api/auth/logout", { method: "POST" }); setUser(null); setAssets([]); setConnections([]); setGenerations([]); setChatMessages([]); setUserMenu(false); };
  const activeSeedance = connections.find(c => c.provider === "seedance" && c.active);
  const filteredAssets = useMemo(() => assets.filter(asset => `${asset.title} ${asset.type}`.toLowerCase().includes(searchText.toLowerCase())), [assets, searchText]);

  if (authLoading) return <div className="screen-loader"><div className="brand-mark">S</div><LoaderCircle className="spin" size={20} /></div>;
  if (!user) return <AuthScreen mode={authMode} setMode={setAuthMode} form={authForm} setForm={setAuthForm} onSubmit={handleAuth} error={authError} busy={busyAction === "auth"} />;

  return (
    <div className="app-shell">
      <aside className={`sidebar ${mobileMenu ? "sidebar-open" : ""}`}>
        <div className="brand-row"><div className="brand-mark">S</div><div><div className="brand-name">seedance<span>studio</span></div><div className="brand-caption">CREATIVE WORKSPACE</div></div><button className="icon-button sidebar-close" onClick={() => setMobileMenu(false)}><X size={18} /></button></div>
        <div className="workspace-switch"><div className="workspace-avatar">{user.name.slice(0, 1).toUpperCase()}</div><div className="workspace-copy"><strong>{user.name}&apos;s workspace</strong><span>Personal plan</span></div><ChevronDown size={15} /></div>
        <div className="nav-label">WORKSPACE</div>
        <nav className="side-nav">
          {NAV.map(item => { const Icon = item.icon; return <button key={item.id} className={`nav-item ${page === item.id ? "active" : ""}`} onClick={() => { setPage(item.id); setMobileMenu(false); }}><Icon size={17} /><span>{item.label}</span>{item.id === "api" && connections.length > 0 && <i className="nav-count">{connections.length}</i>}</button>; })}
        </nav>
        <div className="nav-label nav-label-spaced">PREFERENCES</div>
        <button className={`nav-item ${page === "settings" ? "active" : ""}`} onClick={() => { setPage("settings"); setMobileMenu(false); }}><Settings2 size={17} /><span>Settings</span></button>
        <div className="sidebar-bottom">
          <div className="sidebar-help"><div className="help-icon"><CircleHelp size={16} /></div><div><strong>Need a hand?</strong><span>Read the quick start guide</span></div><ArrowRight size={14} /></div>
          <div className="user-row"><div className="user-avatar">{user.name.slice(0, 1).toUpperCase()}</div><div className="user-copy"><strong>{user.name}</strong><span>{user.email}</span></div><div className="user-menu-wrap"><button className="icon-button" onClick={() => setUserMenu(v => !v)}><MoreHorizontal size={18} /></button>{userMenu && <div className="user-menu"><button onClick={() => setPage("settings")}><Settings2 size={14} /> Settings</button><button onClick={logout}><LogOut size={14} /> Sign out</button></div>}</div></div>
        </div>
      </aside>
      {mobileMenu && <button aria-label="Close navigation" className="mobile-scrim" onClick={() => setMobileMenu(false)} />}

      <main className="main-area">
        <header className="topbar">
          <button className="icon-button mobile-menu-button" onClick={() => setMobileMenu(true)}><Menu size={19} /></button>
          <div className="breadcrumb"><span>Workspace</span><ChevronRight size={13} /><strong>{page === "api" ? "API Hub" : page.charAt(0).toUpperCase() + page.slice(1)}</strong></div>
          <div className="topbar-right"><div className="service-status"><span className="status-dot" /> Workspace ready</div><div className="top-avatar">{user.name.slice(0, 1).toUpperCase()}</div></div>
        </header>

        {page === "studio" && <StudioPage
          prompt={prompt} setPrompt={setPrompt} mode={mode} setMode={setMode} model={model} setModel={setModel}
          resolution={resolution} setResolution={setResolution} ratio={ratio} setRatio={setRatio} duration={duration} setDuration={setDuration}
          audio={audio} setAudio={setAudio} watermark={watermark} setWatermark={setWatermark} cameraFixed={cameraFixed} setCameraFixed={setCameraFixed}
          lastFrame={lastFrame} setLastFrame={setLastFrame} projects={projects} selectedProjectId={selectedProjectId} setSelectedProjectId={setSelectedProjectId} durationMode={durationMode} setDurationMode={setDurationMode} frames={frames} setFrames={setFrames} outputFormat={outputFormat} setOutputFormat={setOutputFormat} serviceTier={serviceTier} setServiceTier={setServiceTier} audioReferenceUrl={audioReferenceUrl} setAudioReferenceUrl={setAudioReferenceUrl} seed={seed} setSeed={setSeed} advanced={advanced} setAdvanced={setAdvanced}
          attached={attached} setAttached={setAttached} assets={assets} uploading={uploading} generating={generating} busyAction={busyAction}
          fileRef={fileRef} promptRef={promptRef} uploadFiles={uploadFiles} generate={generate} messages={chatMessages} onNewSession={newSession}
          activeSeedance={activeSeedance} onBrowseAssets={() => setPage("assets")} />}
        {page === "assets" && <AssetsPage assets={filteredAssets} searchText={searchText} setSearchText={setSearchText} deleteAsset={deleteAsset} syncAsset={syncAsset} busyAction={busyAction} fileRef={fileRef} uploadFiles={uploadFiles} uploading={uploading} activeSeedance={activeSeedance} />}
        {page === "api" && <ApiHubPage connections={connections} onAdd={() => setShowConnectionForm(true)} activate={activateConnection} test={testConnection} remove={deleteConnection} busyAction={busyAction} />}
        {page === "settings" && <SettingsPage connections={connections} onAdd={() => setShowConnectionForm(true)} activate={activateConnection} test={testConnection} remove={deleteConnection} busyAction={busyAction} />}
        {page === "projects" && <ProjectsPage projects={projects} name={projectName} setName={setProjectName} description={projectDescription} setDescription={setProjectDescription} onSubmit={addProject} />}
        {page === "history" && <HistoryPage generations={generations} onRefresh={loadWorkspace} onOpen={(generation) => { setPage("studio"); setChatMessages(items => [...items, { id: `history-${generation.id}`, role: "assistant", content: "Previous generation preview", status: generation.status, generation }]); }} />}
      </main>

      {showConnectionForm && <ConnectionModal form={connectionForm} setForm={setConnectionForm} onClose={() => setShowConnectionForm(false)} onSubmit={addConnection} busy={busyAction === "connection"} />}
      <nav className="mobile-bottom-nav">{NAV.filter(n => ["studio", "assets", "api", "projects"].includes(n.id)).map(item => { const Icon = item.icon; return <button key={item.id} className={page === item.id ? "active" : ""} onClick={() => setPage(item.id)}><Icon size={19} /><span>{item.label}</span></button>; })}</nav>
      {toast && <div className="toast"><CheckCircle2 size={16} />{toast}</div>}
    </div>
  );
}

function AuthScreen({ mode, setMode, form, setForm, onSubmit, error, busy }: any) {
  return <div className="auth-screen"><div className="auth-backdrop" /><div className="auth-card"><div className="brand-row auth-brand"><div className="brand-mark">S</div><div><div className="brand-name">seedance<span>studio</span></div><div className="brand-caption">AI VIDEO WORKSPACE</div></div></div><div className="auth-overline">YOUR CREATIVE ENGINE</div><h1>{mode === "login" ? "Welcome back." : "Make room for ideas."}</h1><p className="muted">Create, remix and organize AI video generations in one focused workspace.</p><form onSubmit={onSubmit} className="auth-form">{mode === "register" && <label>Full name<input value={form.name} onChange={e => setForm((f: any) => ({ ...f, name: e.target.value }))} placeholder="Your name" required minLength={2} /></label>}<label>Email address<input type="email" value={form.email} onChange={e => setForm((f: any) => ({ ...f, email: e.target.value }))} placeholder="you@example.com" required /></label><label>Password<input type="password" value={form.password} onChange={e => setForm((f: any) => ({ ...f, password: e.target.value }))} placeholder={mode === "register" ? "At least 10 characters" : "Your password"} required minLength={mode === "register" ? 10 : 1} /></label>{error && <div className="form-error">{error}</div>}<button className="button-primary auth-submit" disabled={busy}>{busy ? <LoaderCircle className="spin" size={16} /> : <>{mode === "login" ? "Sign in" : "Create account"}<ArrowRight size={16} /></>}</button></form><div className="auth-switch">{mode === "login" ? "New to Seedance Studio?" : "Already have an account?"} <button onClick={() => setMode(mode === "login" ? "register" : "login")}>{mode === "login" ? "Create account" : "Sign in"}</button></div><div className="auth-note"><ShieldCheck size={14} /> API keys are encrypted server-side. Media files are stored outside MongoDB.</div></div><div className="auth-foot">SEEDANCE STUDIO <span>·</span> PRIVATE CREATIVE WORKSPACE</div></div>;
}

function StudioPage(props: any) {
  const modes = [{ id: "text-to-video", label: "Text to video", icon: WandSparkles }, { id: "image-to-video", label: "Image to video", icon: ImageIcon }, { id: "video-to-video", label: "Video to video", icon: Video }, { id: "audio-driven", label: "Audio driven", icon: AudioLines }, { id: "multi-modal", label: "Multi-modal", icon: Aperture }];
  return <div className="page-content studio-content">
    <div className="page-heading"><div><div className="eyebrow">THE CREATIVE WORKSPACE</div><h1>Make something <span>remarkable.</span></h1><p>Turn a thought into a moving image. Your next scene starts here.</p></div><div className="heading-actions"><span className="provider-chip"><span className="provider-dot" /> {props.activeSeedance?.label || "Seedance API not connected"}</span><button className="button-ghost" onClick={props.onBrowseAssets}><FolderOpen size={15} /> Browse assets</button></div></div>
    <div className="studio-grid">
      <section className="composer-card panel">
        <div className="panel-header"><div><span className="section-kicker">CREATE</span><h2>Generation studio</h2></div><div className="live-pill"><span /> READY</div></div>
        {props.projects?.length > 0 && <label className="project-select setting-field"><span>Project</span><div className="select-shell"><select value={props.selectedProjectId} onChange={e => props.setSelectedProjectId(e.target.value)}><option value="">Personal workspace</option>{props.projects.map((project: Project) => <option key={project.id} value={project.id}>{project.name}</option>)}</select><ChevronDown size={15} /></div></label>}
        <div className="mode-tabs">{modes.map(item => { const Icon = item.icon; return <button key={item.id} className={props.mode === item.id ? "selected" : ""} onClick={() => props.setMode(item.id)}><Icon size={16} /><span>{item.label}</span></button>; })}</div>
        <div className="prompt-heading"><label htmlFor="main-prompt">YOUR PROMPT</label><span>{props.prompt.length.toLocaleString()} / 12,000</span></div>
        <textarea ref={props.promptRef} id="main-prompt" className="prompt-input" value={props.prompt} onChange={e => props.setPrompt(e.target.value)} placeholder="Describe the scene, subject, camera movement, lighting and mood..." maxLength={12000} />
        <div className="prompt-tools"><button className="tool-button" onClick={() => props.fileRef.current?.click()}><Paperclip size={15} /> Add media</button><span className="tool-hint">Images/video · max 200 MB each; audio via URL</span><input ref={props.fileRef} type="file" accept="image/*,video/*" multiple hidden onChange={(e) => e.target.files && props.uploadFiles(e.target.files)} /></div>
        {props.attached.length > 0 && <div className="attached-strip">{props.attached.map((asset: Asset) => <div className="attached-item" key={asset.id}>{asset.type === "image" ? <img src={asset.thumb || asset.src} alt={asset.title} /> : asset.type === "video" ? <div className="attachment-video"><video src={asset.src} poster={asset.thumb || undefined} muted playsInline preload="metadata" /><Video size={15} /></div> : <div className="attachment-video"><AudioLines size={17} /></div>}<span>{asset.title}</span>{asset.type === "image" && <select aria-label={`Image role for ${asset.title}`} value={asset.role || (props.mode === "image-to-video" ? "first_frame" : "reference_image")} onChange={e => props.setAttached((items: Asset[]) => items.map(item => item.id === asset.id ? { ...item, role: e.target.value as Asset["role"] } : item))}><option value="first_frame">First frame</option><option value="last_frame">Last frame</option><option value="reference_image">Reference image</option></select>}<button onClick={() => props.setAttached((items: Asset[]) => items.filter(a => a.id !== asset.id))}><X size={13} /></button></div>)}</div>}
        {props.uploading && <div className="upload-progress"><LoaderCircle className="spin" size={14} /> Uploading media to YourImageShare…</div>}
        {(props.mode === "audio-driven" || props.mode === "multi-modal") && <label className="audio-url-field"><span>PUBLIC AUDIO REFERENCE URL</span><input value={props.audioReferenceUrl} onChange={e => props.setAudioReferenceUrl(e.target.value)} placeholder="https://example.com/reference-audio.mp3" type="url" /></label>}
        <div className="settings-title"><span>GENERATION SETTINGS</span><span className="setting-divider" /></div>
        <div className="settings-grid">
          <label className="setting-field wide"><span>Model</span><div className="select-shell"><select value={props.model} onChange={e => props.setModel(e.target.value)}>{MODELS.map(m => <option key={m.id} value={m.id}>{m.name} · {m.provider}</option>)}</select><ChevronDown size={15} /></div></label>
          <label className="setting-field"><span>Resolution</span><div className="segmented">{["480p", "720p", "1080p"].map(v => <button key={v} className={props.resolution === v ? "on" : ""} onClick={() => props.setResolution(v)}>{v}</button>)}</div></label>
          <label className="setting-field"><span>Aspect ratio</span><div className="select-shell"><select value={props.ratio} onChange={e => props.setRatio(e.target.value)}>{["16:9", "9:16", "1:1", "3:4", "4:3", "adaptive"].map(v => <option key={v}>{v}</option>)}</select><ChevronDown size={15} /></div></label>
          <label className="setting-field"><span>Length mode</span><div className="select-shell"><select value={props.durationMode} onChange={e => props.setDurationMode(e.target.value)}><option value="duration">Duration (seconds)</option><option value="frames">Frame count</option></select><ChevronDown size={15} /></div></label>
          <label className="setting-field"><span>{props.durationMode === "frames" ? "Frames" : "Duration"} <small>{props.durationMode === "frames" ? "frame count" : "seconds"}</small></span><div className="stepper"><button onClick={() => props.durationMode === "frames" ? props.setFrames((v: number) => Math.max(1, v - 24)) : props.setDuration((v: number) => Math.max(1, v - 1))}>−</button><b>{props.durationMode === "frames" ? props.frames : `${props.duration}s`}</b><button onClick={() => props.durationMode === "frames" ? props.setFrames((v: number) => v + 24) : props.setDuration((v: number) => v + 1)}>+</button></div></label>
          <label className="setting-field"><span>Output format</span><div className="select-shell"><select value={props.outputFormat} onChange={e => props.setOutputFormat(e.target.value)}><option value="mp4">MP4</option><option value="mov">MOV</option></select><ChevronDown size={15} /></div></label>
          <div className="setting-field"><span>Audio generation</span><Toggle value={props.audio} onChange={props.setAudio} /></div>
        </div>
        <button className="advanced-toggle" onClick={() => props.setAdvanced((v: boolean) => !v)}><SlidersHorizontal size={14} /> Advanced controls <ChevronDown className={props.advanced ? "rotate" : ""} size={14} /></button>
        {props.advanced && <div className="advanced-panel"><label className="setting-field"><span>Seed <small>-1 = random</small></span><input className="dark-input" value={props.seed} onChange={e => props.setSeed(e.target.value)} inputMode="numeric" /></label><div className="advanced-switches"><ToggleLine label="Watermark" value={props.watermark} onChange={props.setWatermark} /><ToggleLine label="Fixed camera" value={props.cameraFixed} onChange={props.setCameraFixed} /><ToggleLine label="Return last frame" value={props.lastFrame} onChange={props.setLastFrame} /></div><label className="setting-field"><span>Service tier</span><div className="select-shell"><select value={props.serviceTier} onChange={e => props.setServiceTier(e.target.value)}><option value="default">Default</option><option value="flex">Flex</option></select><ChevronDown size={15} /></div></label><p className="muted tiny">Draft generation is disabled by this gateway. Choose duration or frame count, not both.</p></div>}
        <div className="generate-footer"><div className="credit-estimate"><Zap size={14} /><span>Credits are provider-managed</span></div><button className="button-primary generate-button" onClick={props.generate} disabled={props.generating || props.uploading || !props.prompt.trim()}>{props.busyAction === "generate" || props.generating ? <><LoaderCircle className="spin" size={16} /> Submitting…</> : <><Sparkles size={16} /> Generate video <ArrowRight size={16} /></>}</button></div>
      </section>
      <section className="chat-card panel">
        <div className="panel-header"><div><span className="section-kicker">LIVE SESSION</span><h2>Creation chat</h2></div><button className="icon-button" title="New session" onClick={props.onNewSession}><Plus size={17} /></button></div>
        <div className="chat-stream">
          {props.messages.length === 0 ? <div className="chat-empty"><div className="chat-empty-icon"><MessageSquare size={22} /></div><h3>Your creative thread</h3><p>Prompts, references and generated video previews will appear here as a visual conversation.</p><div className="chat-example"><div className="example-avatar"><Sparkles size={13} /></div><span>Assistant</span><p>Ready when you are. Describe a scene to start your first generation.</p></div></div> : props.messages.slice(-12).map((message: ChatMessage) => <ChatBubble key={message.id} message={message} />)}
        </div>
        <div className="chat-compose-hint"><span className="tiny-orb" /><span>Chat preview stays in sync with task status</span><span className="secure-tag"><ShieldCheck size={12} /> PRIVATE</span></div>
      </section>
    </div>
    <div className="feature-strip"><div><div className="feature-icon violet"><Zap size={17} /></div><div><strong>One creative workspace</strong><span>Generate, preview and organize</span></div></div><div><div className="feature-icon blue"><CloudUpload size={17} /></div><div><strong>External media storage</strong><span>Uploads stay out of MongoDB</span></div></div><div><div className="feature-icon teal"><ShieldCheck size={17} /></div><div><strong>Encrypted credentials</strong><span>Keys never return to the browser</span></div></div></div>
  </div>;
}

function ChatBubble({ message }: { message: ChatMessage }) {
  const isUser = message.role === "user";
  const generation = message.generation;
  const video = generation?.videoUrl;
  return <div className={`chat-message ${isUser ? "from-user" : "from-assistant"}`}>
    <div className="message-avatar">{isUser ? "F" : <Sparkles size={14} />}</div>
    <div className="message-body"><div className="message-meta"><strong>{isUser ? "You" : "Studio assistant"}</strong><span>{isUser ? "Prompt" : generation ? statusLabel(message.status || generation.status) : "Preview"}</span></div>
      <div className="message-text">{message.content}</div>
      {!!message.attachments?.length && <div className="chat-attachments">{message.attachments.map(a => <div key={a.id} className="chat-attachment">{a.type === "image" ? <img src={a.thumb || a.src} alt={a.title} /> : a.type === "video" ? <video className="chat-attachment-video" src={a.src} poster={a.thumb || undefined} muted playsInline preload="metadata" controls /> : <div className="chat-attachment-icon"><AudioLines size={16} /></div>}<span>{a.title}</span></div>)}</div>}
      {generation && <div className="generation-preview-card">{video && generation.status === "succeeded" ? <div className="video-preview-wrap"><video src={video} controls playsInline preload="metadata" /><div className="video-preview-label"><CheckCircle2 size={13} /> Video preview</div></div> : <div className="preview-placeholder"><div className="preview-spinner">{["queued", "running"].includes(generation.status) ? <LoaderCircle className="spin" size={21} /> : <Film size={21} />}</div><div><strong>{generation.status === "failed" ? "Generation failed" : generation.status === "expired" ? "Task expired" : generation.status === "succeeded" ? "Generation completed" : "Creating your scene"}</strong><span>{generation.status === "queued" ? "Waiting for the model queue" : generation.status === "running" ? "Rendering frames and synchronizing output" : generation.errorMessage || `${generation.model} · ${generation.ratio || "16:9"}`}</span></div></div>}
        {generation.lastFrameUrl && <a className="last-frame-link" href={generation.lastFrameUrl} target="_blank" rel="noreferrer"><ImageIcon size={13} /> View last frame</a>}
        {generation.status === "succeeded" && video && <div className="preview-actions"><a href={video} target="_blank" rel="noreferrer"><Play size={13} /> Open preview</a><a href={video} download><ArrowDownToLine size={13} /> Download</a></div>}
      </div>}
    </div>
  </div>;
}

function Toggle({ value, onChange }: { value: boolean; onChange: (v: boolean) => void }) { return <button className={`toggle ${value ? "checked" : ""}`} onClick={() => onChange(!value)} aria-pressed={value}><span /></button>; }
function ToggleLine({ label, value, onChange }: { label: string; value: boolean; onChange: (v: boolean) => void }) { return <div className="toggle-line"><span>{label}</span><Toggle value={value} onChange={onChange} /></div>; }

function AssetsPage({ assets, searchText, setSearchText, deleteAsset, syncAsset, busyAction, fileRef, uploadFiles, uploading, activeSeedance }: any) {
  return <div className="page-content"><PageTitle eyebrow="YOUR MEDIA LIBRARY" title="Assets" description="Reference images and video clips stored outside your database. Audio references are linked by URL." action={<button className="button-primary" onClick={() => fileRef.current?.click()}><Plus size={16} /> Upload assets</button>} /><div className="asset-toolbar"><div className="search-box"><Search size={16} /><input placeholder="Search assets…" value={searchText} onChange={e => setSearchText(e.target.value)} /></div><div className="storage-note"><CloudUpload size={14} /> Media hosted by YourImageShare</div><input ref={fileRef} type="file" accept="image/*,video/*" multiple hidden onChange={(e) => e.target.files && uploadFiles(e.target.files)} /></div>{uploading && <div className="upload-progress"><LoaderCircle className="spin" size={14} /> Uploading assets…</div>}<div className="asset-grid">{assets.map((asset: Asset) => <div className="asset-card panel" key={asset.id}><div className="asset-thumb">{asset.type === "image" ? <img src={asset.thumb || asset.src} alt={asset.title} /> : asset.type === "video" ? <video src={asset.src} muted playsInline preload="metadata" /> : <div className="asset-audio"><AudioLines size={28} /></div>}<span className="asset-type">{asset.type}</span><button className="asset-delete" title="Delete asset" onClick={() => deleteAsset(asset)}><Trash2 size={14} /></button></div><div className="asset-info"><strong title={asset.title}>{asset.title}</strong><span>{formatSize(asset.size)} <i>·</i> YourImageShare</span></div><div className="asset-link-row"><a href={asset.src} target="_blank" rel="noreferrer">Open source <ArrowRight size={12} /></a><button onClick={() => navigator.clipboard.writeText(asset.src)}>Copy URL</button></div><div className="asset-sync-row"><span>{asset.seedanceStatus ? `Seedance: ${asset.seedanceStatus}` : "External media"}</span><button onClick={() => syncAsset(asset)} disabled={busyAction === asset.id || (asset.seedanceStatus === "Active" && (asset.seedanceConnectionId === (activeSeedance?.id || "env-fallback")))}>{busyAction === asset.id ? <LoaderCircle className="spin" size={11} /> : <RefreshCw size={11} />} {asset.seedanceStatus === "Active" && (asset.seedanceConnectionId === (activeSeedance?.id || "env-fallback")) ? "Ready" : "Sync to Seedance"}</button></div></div>)}</div>{assets.length === 0 && <EmptyState icon={<ImageIcon size={23} />} title="Your library is waiting" description="Upload a reference image or source clip. Original files are stored by YourImageShare, not MongoDB; audio references use a public URL." action={<button className="button-primary" onClick={() => fileRef.current?.click()}><Upload size={15} /> Upload first asset</button>} />}</div>;
}

function ApiHubPage({ connections, onAdd, activate, test, remove, busyAction }: any) {
  const providers = [{ id: "seedance", title: "Seedance Video API", detail: "Video generation, task polling and asset references", state: "Implemented" }, { id: "yourimageshare", title: "YourImageShare", detail: "External image and video storage", state: "Implemented" }, { id: "custom", title: "Custom provider adapters", detail: "Register credentials now; add an adapter before sending generation requests", state: "Extensible" }];
  return <div className="page-content"><PageTitle eyebrow="PROVIDER ECOSYSTEM" title="API Hub" description="Connect the services behind your creative pipeline and switch credentials without redeploying." action={<button className="button-primary" onClick={onAdd}><Plus size={16} /> Add API connection</button>} /><div className="api-overview-grid">{providers.map(p => <div className="provider-card panel" key={p.id}><div className={`provider-symbol ${p.id}`}><Command size={20} /></div><div className="provider-card-top"><span className="implemented-tag">{p.state}</span><h3>{p.title}</h3><p>{p.detail}</p></div><div className="provider-card-bottom"><span>{connections.filter((c: Connection) => c.provider === p.id).length} connection(s)</span><button onClick={onAdd}>Configure <ArrowRight size={13} /></button></div></div>)}</div><div className="section-heading-row"><div><span className="section-kicker">CREDENTIAL VAULT</span><h2>Connected credentials</h2></div><span className="muted">{connections.length} saved</span></div><ConnectionList connections={connections} activate={activate} test={test} remove={remove} busyAction={busyAction} /></div>;
}

function SettingsPage({ connections, onAdd, activate, test, remove, busyAction }: any) {
  return <div className="page-content"><PageTitle eyebrow="WORKSPACE PREFERENCES" title="Settings" description="Manage API credentials and provider connection security." /><div className="settings-layout"><div className="settings-menu"><div className="settings-menu-item active"><KeyRound size={16} /> API keys</div></div><div className="settings-main"><div className="section-heading-row"><div><span className="section-kicker">SECURE CONNECTIONS</span><h2>API key management</h2><p className="muted">Add multiple credentials and choose which key is active for each provider.</p></div><button className="button-primary" onClick={onAdd}><Plus size={15} /> Add key</button></div><ConnectionList connections={connections} activate={activate} test={test} remove={remove} busyAction={busyAction} /><div className="security-callout"><ShieldCheck size={19} /><div><strong>Your credentials stay private</strong><p>Keys are encrypted with AES-256-GCM before storage. Only masked values are returned to the browser. Keep the encryption key outside your source repository.</p></div></div><div className="settings-info-grid"><div className="panel info-tile"><span>SESSION</span><strong>HTTP-only cookie</strong><small>7-day signed session, SameSite=Lax</small></div><div className="panel info-tile"><span>MEDIA STORAGE</span><strong>YourImageShare</strong><small>Only metadata and URLs are stored in MongoDB</small></div><div className="panel info-tile"><span>KEY ENCRYPTION</span><strong>AES-256-GCM</strong><small>Per-secret nonce and authentication tag</small></div></div></div></div></div>;
}

function ConnectionList({ connections, activate, test, remove, busyAction }: any) {
  if (!connections.length) return <EmptyState icon={<KeyRound size={23} />} title="No API keys connected" description="Add your Seedance key to enable video generation. You can save multiple keys and switch between them." action={null} />;
  return <div className="connection-list">{connections.map((connection: Connection) => <div key={connection.id} className="connection-row panel"><div className={`connection-icon ${connection.provider}`}><KeyRound size={17} /></div><div className="connection-details"><div className="connection-name"><strong>{connection.label}</strong>{connection.active && <span className="active-badge"><Check size={11} /> ACTIVE</span>}</div><span>{connection.provider.toUpperCase()} <i>·</i> {connection.baseUrl}</span><code>{connection.maskedKey || "••••••••••••"}</code></div><div className={`connection-state ${connection.connectionStatus}`}><span />{connection.connectionStatus}</div><div className="connection-actions"><button className="button-ghost compact" onClick={() => test(connection)} disabled={busyAction === connection.id}>{busyAction === connection.id ? <LoaderCircle className="spin" size={13} /> : <RefreshCw size={13} />} Test</button>{!connection.active && <button className="button-outline compact" onClick={() => activate(connection)} disabled={busyAction === connection.id}>Activate</button>}<button className="icon-button danger-icon" onClick={() => remove(connection)} title="Remove API key"><Trash2 size={15} /></button></div></div>)}</div>;
}

function ProjectsPage({ projects, name, setName, description, setDescription, onSubmit }: any) {
  return <div className="page-content"><PageTitle eyebrow="ORGANIZE YOUR WORK" title="Projects" description="Keep campaigns, experiments and visual worlds organized." /><form className="create-project panel" onSubmit={onSubmit}><div className="create-project-icon"><Plus size={20} /></div><div className="project-form-fields"><strong>Create a project</strong><input value={name} onChange={e => setName(e.target.value)} placeholder="Project name" required minLength={2} /><input value={description} onChange={e => setDescription(e.target.value)} placeholder="Short description (optional)" /><button className="button-primary" type="submit">Create project <ArrowRight size={14} /></button></div></form><div className="section-heading-row"><div><span className="section-kicker">YOUR WORKSPACES</span><h2>All projects</h2></div><span className="muted">{projects.length} projects</span></div><div className="project-grid">{projects.map((project: Project) => <div className="project-card panel" key={project.id}><div className="project-card-art" style={{ "--project-color": project.color || "#716BFF" } as CSSProperties}><FolderOpen size={26} /><span>PROJECT SPACE</span></div><div className="project-card-copy"><strong>{project.name}</strong><p>{project.description || "No description yet."}</p><span>Created workspace <ArrowRight size={13} /></span></div></div>)}</div>{!projects.length && <EmptyState icon={<Folder size={23} />} title="No projects yet" description="Create a project to group prompts, generations and source assets." action={null} />}</div>;
}

function HistoryPage({ generations, onRefresh, onOpen }: any) {
  return <div className="page-content"><PageTitle eyebrow="YOUR GENERATION TIMELINE" title="History" description="Every generation request, task status and completed preview in one place." action={<button className="button-ghost" onClick={onRefresh}><RefreshCw size={15} /> Refresh history</button>} /><div className="history-list">{generations.map((item: Generation) => <button className="history-row panel" key={item.id} onClick={() => onOpen(item)}><div className="history-art">{item.videoUrl ? <video src={item.videoUrl} muted preload="metadata" /> : <Film size={20} />}</div><div className="history-copy"><strong>{item.prompt}</strong><span>{item.model} <i>·</i> {item.ratio || "16:9"} <i>·</i> {item.duration || 5}s</span></div><div className={`history-status ${item.status}`}><span />{statusLabel(item.status)}</div><ChevronRight size={16} /></button>)}</div>{!generations.length && <EmptyState icon={<Clock3 size={23} />} title="No generations yet" description="Your submitted video tasks will show up here with a preview when complete." action={null} />}</div>;
}

function PageTitle({ eyebrow, title, description, action }: any) { return <div className="page-heading secondary-heading"><div><div className="eyebrow">{eyebrow}</div><h1>{title}</h1><p>{description}</p></div>{action && <div className="heading-actions">{action}</div>}</div>; }
function EmptyState({ icon, title, description, action }: any) { return <div className="empty-state panel"><div className="empty-icon">{icon}</div><h3>{title}</h3><p>{description}</p>{action}</div>; }

function ConnectionModal({ form, setForm, onClose, onSubmit, busy }: any) {
  return <div className="modal-backdrop" onClick={onClose}><div className="modal-card panel" onClick={e => e.stopPropagation()}><div className="modal-header"><div><span className="section-kicker">CONNECT A PROVIDER</span><h2>Add API connection</h2></div><button className="icon-button" onClick={onClose}><X size={18} /></button></div><form className="connection-form" onSubmit={onSubmit}><label>Provider<select value={form.provider} onChange={e => setForm((v: any) => ({ ...v, provider: e.target.value, baseUrl: e.target.value === "seedance" ? "https://open.fast-api.org" : e.target.value === "yourimageshare" ? "https://yourimageshare.com/api" : "" }))}><option value="seedance">Seedance Video API</option><option value="yourimageshare">YourImageShare</option><option value="custom">Custom provider</option></select></label><label>Connection name<input value={form.label} onChange={e => setForm((v: any) => ({ ...v, label: e.target.value }))} placeholder="e.g. Seedance Production" required minLength={2} /></label><label>Base URL<input value={form.baseUrl} onChange={e => setForm((v: any) => ({ ...v, baseUrl: e.target.value }))} placeholder="https://api.example.com" required type="url" /></label><label>API key<input value={form.apiKey} onChange={e => setForm((v: any) => ({ ...v, apiKey: e.target.value }))} placeholder="Paste your provider key" required type="password" autoComplete="off" /></label><label className="checkbox-label"><input type="checkbox" checked={form.makeActive} onChange={e => setForm((v: any) => ({ ...v, makeActive: e.target.checked }))} /> Make this the active key for this provider</label><div className="modal-security"><ShieldCheck size={15} /><span>Encrypted on the server. The full key will not be displayed again.</span></div><div className="modal-actions"><button type="button" className="button-ghost" onClick={onClose}>Cancel</button><button type="submit" className="button-primary" disabled={busy || !form.apiKey}>{busy ? <LoaderCircle className="spin" size={15} /> : <Plus size={15} />} Save connection</button></div></form></div></div>;
}
