# Seedance Studio

> **AI model:** GPT-6 by OpenAI  
> **Implementation agent:** OpenAI GPT-6  
> **Project owner:** Fadil Muhammed  
> **Status:** Working foundation · configure credentials and run the deployment checks before production use

Seedance Studio is a responsive, multi-provider AI video workspace. It combines a chat-style creation flow, Seedance task orchestration, an external media library powered by YourImageShare, encrypted provider credentials, project organization and a generation history.

The current visual system is **Midnight Iris**: deep navy surfaces, violet/indigo controls, and a restrained teal signal color. It replaces the earlier neon-lime direction with a quieter, cinematic editing environment.

## What is implemented

- Responsive studio dashboard with text-to-video, image-to-video, video-to-video, audio-driven and multi-modal modes (audio is supplied through a public reference URL; YourImageShare uploads images and video).
- Prompt editor, reference-media attachments with first-frame/last-frame/reference roles, model/resolution/ratio/duration-or-frames controls, MP4/MOV output, audio and watermark toggles, camera-fixed setting, seed, service-tier and last-frame options.
- Chat-style prompt and generation previews, task state updates, embedded video player, last-frame link and download link.
- Seedance generation create, task query, upstream task history (`GET /api/generations?remote=1`) and completed-task deletion.
- Seedance Asset Library registration for an uploaded YourImageShare asset, including asset-group creation and status checking.
- Multiple per-provider API connections, active-key switching, default selection, masked credential display and connection tests for supported adapters.
- AES-256-GCM encryption for saved provider API keys. Raw secrets never return to the browser.
- YourImageShare upload proxy for images and videos; audio references use a public URL because the supplied upload API documentation does not describe audio upload support. Files are sent to YourImageShare; MongoDB stores only metadata, URLs, provider IDs and application records.
- Large-upload chunking for files over 100 MB, using 5 MB chunks and YourImageShare's documented 200 MB ceiling.
- Project creation and generation-to-project association, assets view, history view, settings and API hub.
- Cookie-based login/register, password hashing and authenticated API routes.

## Architecture

```mermaid
flowchart LR
  U[Browser / Mobile UI] --> N[Next.js App Router]
  N --> A[Auth + session cookie]
  N --> DB[(MongoDB metadata only)]
  N --> S[Seedance adapter]
  N --> Y[YourImageShare adapter]
  S --> V[Seedance gateway\nopen.fast-api.org]
  Y --> I[YourImageShare storage]
  V -->|temporary result URL| N
  N -->|import result URL| I
  I -->|permanent media URL| DB
```

### Data-storage rule

MongoDB is **not** used as a file store. The application never writes uploaded image or video bytes into MongoDB/GridFS. The upload endpoint forwards image/video bytes to YourImageShare and stores only returned identifiers, URLs, dimensions, file size, media type, visibility and ownership metadata in MongoDB. Generation prompts, task IDs, statuses, chat messages, projects and encrypted API credentials are application metadata.

The app currently uploads with YourImageShare visibility set to **unlisted**. Anyone with an unlisted direct URL may be able to access that media. Do not upload private, confidential or sensitive footage unless you have reviewed the hosting provider's privacy and access controls. This application currently uses the `src` direct URL returned by YourImageShare because its docs identify `src` as the stable URL for embedding and saving.

## Stack

- Next.js 15 App Router / React 19 / TypeScript
- MongoDB + Mongoose for metadata
- AES-256-GCM for encrypted provider secrets
- JWT signed session in an HTTP-only cookie
- bcryptjs for password hashing
- Seedance-compatible REST gateway
- YourImageShare REST media API (image/video upload and external references)
- Lucide icons and custom responsive CSS

## Quick start

### 1. Requirements

- Node.js 20.10+ (Node 22 recommended)
- npm 10+
- MongoDB connection string
- YourImageShare API key (use a full key for listing/deletion, or upload-only key when those features are disabled)
- Seedance gateway API key

### 2. Configure environment

```bash
cp .env.example .env
```

Create secure secrets:

```bash
openssl rand -hex 32
openssl rand -base64 48
```

Set the first output as `APP_ENCRYPTION_KEY` (exactly 64 hex characters) and use a strong second output as `JWT_SECRET`. Fill in MongoDB, YourImageShare and Seedance credentials in `.env`.

**Never** prefix secrets with `NEXT_PUBLIC_`. Never commit `.env`. `.env.example` contains placeholders only.

### 3. Install and run

```bash
npm install
npm run dev
```

Open `http://localhost:3000`.

Set `ALLOW_PUBLIC_REGISTRATION=true` only while creating accounts. For a private deployment, create the owner account, then set it to `false` and redeploy. The first registered account is not automatically made an administrator; this starter currently provides a personal workspace rather than multi-role organization administration.

### 4. Configure API connections

In Settings → API Keys, add a Seedance connection:

- Provider: Seedance Video API
- Base URL: `https://open.fast-api.org`
- API key: your own Seedance bearer key

The API key is encrypted before storage. You can save multiple Seedance keys and activate one. A generation is polled using the same saved connection ID that submitted it, so switching the active key does not accidentally poll an old task with another key.

For uploads, configure `YOURIMAGESHARE_API_KEY` in the server environment or add an active YourImageShare full API key in Settings. The API uses the `X-API-Key` header. An upload-only key can upload files but cannot list, look up, edit or delete them; use the full API key for all features currently exposed by this app.

## Seedance API integration

The Seedance adapter follows the supplied `Video Generation + Asset Library Integration` guide:

| Operation | Request |
|---|---|
| Create task | `POST /api/v3/contents/generations/tasks` |
| Query task | `GET /api/v3/contents/generations/tasks/{id}` |
| List tasks | `GET /api/v3/contents/generations/tasks` |
| Delete completed task | `DELETE /api/v3/contents/generations/tasks/{id}` |
| Create asset group | `POST /?Action=CreateAssetGroup&Version=2024-01-01` |
| Create asset | `POST /?Action=CreateAsset&Version=2024-01-01` |
| Get asset | `POST /?Action=GetAsset&Version=2024-01-01` |
| List assets | `POST /?Action=ListAssets&Version=2024-01-01` |
| Update asset | `POST /?Action=UpdateAsset&Version=2024-01-01` |
| Delete asset | `POST /?Action=DeleteAsset&Version=2024-01-01` |

The UI currently creates tasks and can register YourImageShare references into Seedance's asset group. Asset listing, update and delete are present in the API specification but are not yet exposed as full remote-library management screens. The local Assets screen lists the app's metadata records and deletes the corresponding YourImageShare upload.

Important gateway constraints from the supplied guide:

- `duration` and `frames` are mutually exclusive; the Studio exposes both modes.
- `output_format` supports `mp4` and `mov`.
- `draft=true` is unsupported by this gateway; the adapter always sends `false`.
- Queued/running tasks cannot be cancelled through this gateway. Only succeeded/failed tasks can be deleted.
- Task lookup is limited to the last seven days.
- A generated `content.video_url` is valid for 24 hours.
- The app attempts to archive successful video and last-frame URLs to YourImageShare so the workspace does not rely on the temporary gateway URL. If archival fails, the UI retains the temporary preview URL and reports the archival error.
- Provider credit cost is not invented or hardcoded. The UI labels credit usage as provider-managed.

## YourImageShare integration

Based on the provider's API documentation:

- Base URL: `https://yourimageshare.com/api`
- Authentication header: `X-API-Key: YOUR_KEY`
- Upload: `POST /` with multipart field `uploads`
- Chunk upload: `POST /chunk` with `upload_id`, `index`, `total`, and `chunk` fields
- List: `GET /?page=1`
- Delete: `DELETE /{id}`

The server uses direct multipart upload through 100 MB and 5 MB chunking for files larger than 100 MB, up to 200 MB. Only the image/video formats listed in the provider documentation are accepted. Use the returned `src` field as the stable URL; `path` may change after provider-side conversion. The browser never receives the YourImageShare API key. The current connection test, remote deletion and result archival require a full API key; upload-only keys are not yet supported as a complete connection type.

## Application API routes

All routes except health and login/register require the signed session cookie.

| Route | Method | Purpose |
|---|---|---|
| `/api/health` | GET | Database readiness check |
| `/api/auth/register` | POST | Create account when registration is enabled |
| `/api/auth/login` | POST | Sign in |
| `/api/auth/logout` | POST | Clear session |
| `/api/auth/me` | GET | Current user |
| `/api/connections` | GET / POST | List masked API connections / add encrypted connection |
| `/api/connections/:id` | PATCH / DELETE | Activate, disable, set default, rename or delete a connection |
| `/api/connections/:id/test` | POST | Test supported provider credentials |
| `/api/uploads` | GET / POST | List asset metadata / upload to YourImageShare |
| `/api/uploads/:id` | DELETE | Delete remote YourImageShare object and local metadata |
| `/api/uploads/:id/sync` | POST | Register a media URL in Seedance Asset Library |
| `/api/generations` | GET / POST | List local history / submit a generation; add `?remote=1` to fetch upstream task history |
| `/api/generations/:id` | GET / DELETE | Poll task and archive result / delete a completed task |
| `/api/conversations` | GET / POST | List or create chat threads |
| `/api/projects` | GET / POST | List or create projects |

## Provider adapter design

Seedance is the implemented video-generation adapter. YourImageShare is the implemented media-storage adapter. The API Hub also allows saving a `custom` provider connection, but a credential record alone does not make an unknown provider compatible with video generation. Add a provider-specific adapter for each additional platform, mapping its model list, request schema, status polling, result URLs and error format to the studio's internal task contract. This avoids pretending every platform exposes the same API.

## Deployment

Deploy as a Node.js Next.js application on a host that supports server-side route handlers and request bodies up to 200 MB for the optional large-file upload path. Configure every value from `.env.example` in the host's encrypted environment-variable store. Use a managed MongoDB deployment with TLS and a least-privilege database user.

Recommended production additions before public launch:

1. Replace the included per-process in-memory request limiter with Redis or a platform rate limiter before deploying multiple app instances. The current limiter protects login, registration, generation submission and uploads, but does not coordinate across servers.
2. Add an account verification and password-reset flow, login throttling and a first-owner bootstrap process.
3. Add a queue worker for reliable status polling and result archival; current polling runs while the Studio page is open.
4. Add malware/content scanning policy and explicit media retention controls appropriate to your workflow.
5. Add remote asset reconciliation, retry queues and alerting for 429/504/500 provider errors.
6. Add provider-specific credit usage and pricing only after the relevant provider returns authoritative data.
7. Configure HTTPS, CSP, security headers, request-size limits and log redaction at the deployment layer.

## Scripts

```bash
npm run dev        # development server
npm run typecheck  # TypeScript check
npm run build      # production build
npm start          # production server
```

## Security checklist

- [ ] `.env` is not committed.
- [ ] `APP_ENCRYPTION_KEY` is backed up securely; losing it makes stored provider keys unrecoverable.
- [ ] `JWT_SECRET` is unique and at least 32 characters.
- [ ] Public registration is disabled after initial account setup.
- [ ] Use a full YourImageShare key only in the server environment or encrypted settings vault.
- [ ] Rotate any credential that has been pasted into chat, an issue, a commit or a public file.
- [ ] Review unlisted-media access semantics before storing sensitive footage.

## License

MIT. See [LICENSE](./LICENSE).

## Validation snapshot

See [docs/VALIDATION.md](./docs/VALIDATION.md) for the checks completed for this source snapshot and the checks that still require installed dependencies and live provider credentials.
