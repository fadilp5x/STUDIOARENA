const DEFAULT_BASE_URL = process.env.YOURIMAGESHARE_BASE_URL || "https://yourimageshare.com/api";
function baseUrl(override?: string) { return (override || DEFAULT_BASE_URL).replace(/\/$/, ""); }
const CHUNK_SIZE = 5 * 1024 * 1024;
const DIRECT_LIMIT = 100 * 1024 * 1024;
const MAX_FILE_SIZE = 200 * 1024 * 1024;

function apiKey(override?: string) {
  const key = override || process.env.YOURIMAGESHARE_API_KEY;
  if (!key) throw new Error("YOURIMAGESHARE_API_KEY is not configured on the server");
  return key;
}

async function parseResponse(response: Response) {
  const body = await response.json().catch(() => ({}));
  if (!response.ok || body?.type === "error") {
    const detail = body?.errors || body?.msg || body?.message || `YourImageShare returned ${response.status}`;
    throw new Error(`${response.status}: ${typeof detail === "string" ? detail : JSON.stringify(detail)}`);
  }
  return body?.data ?? body;
}

export async function uploadMedia(file: File, title?: string, keyOverride?: string, baseUrlOverride?: string) {
  if (file.size <= 0) throw new Error("The selected file is empty");
  if (file.size > MAX_FILE_SIZE) throw new Error("Files must be 200MB or smaller");
  const common = { title: (title || file.name).slice(0, 90), visibility: "unlisted", keep_original: "1" };

  if (file.size <= DIRECT_LIMIT) {
    const form = new FormData();
    form.set("uploads", file, file.name);
    for (const [key, value] of Object.entries(common)) form.set(key, value);
    const response = await fetch(baseUrl(baseUrlOverride), { method: "POST", headers: { "X-API-Key": apiKey(keyOverride) }, body: form, cache: "no-store" });
    return parseResponse(response);
  }

  const uploadId = crypto.randomUUID().replaceAll("-", "");
  const total = Math.ceil(file.size / CHUNK_SIZE);
  const bytes = Buffer.from(await file.arrayBuffer());
  for (let index = 0; index < total; index += 1) {
    const start = index * CHUNK_SIZE;
    const form = new FormData();
    form.set("upload_id", uploadId);
    form.set("index", String(index));
    form.set("total", String(total));
    form.set("chunk", new Blob([bytes.subarray(start, Math.min(start + CHUNK_SIZE, bytes.length))]), `${file.name}.part`);
    const response = await fetch(`${baseUrl(baseUrlOverride)}/chunk`, { method: "POST", headers: { "X-API-Key": apiKey(keyOverride) }, body: form, cache: "no-store" });
    await parseResponse(response);
  }
  const finish = new FormData();
  finish.set("upload_id", uploadId);
  finish.set("filename", file.name);
  for (const [key, value] of Object.entries(common)) finish.set(key, value);
  const response = await fetch(baseUrl(baseUrlOverride), { method: "POST", headers: { "X-API-Key": apiKey(keyOverride) }, body: finish, cache: "no-store" });
  return parseResponse(response);
}

export async function importRemoteMedia(url: string, title: string, keyOverride?: string, baseUrlOverride?: string) {
  const form = new FormData();
  form.set("url", url);
  form.set("title", title.slice(0, 90));
  form.set("visibility", "unlisted");
  const response = await fetch(baseUrl(baseUrlOverride), { method: "POST", headers: { "X-API-Key": apiKey(keyOverride) }, body: form, cache: "no-store" });
  return parseResponse(response);
}

export async function deleteRemoteMedia(id: string, keyOverride?: string, baseUrlOverride?: string) {
  const response = await fetch(`${baseUrl(baseUrlOverride)}/${encodeURIComponent(id)}`, { method: "DELETE", headers: { "X-API-Key": apiKey(keyOverride) }, cache: "no-store" });
  if (response.status === 404) return true;
  await parseResponse(response);
  return true;
}

export async function testYourImageShareKey(keyOverride?: string, baseUrlOverride?: string) {
  const response = await fetch(`${baseUrl(baseUrlOverride)}?page=1`, { headers: { "X-API-Key": apiKey(keyOverride) }, cache: "no-store" });
  await parseResponse(response);
  return true;
}
