import mongoose from "mongoose";

const MONGODB_URI = () => process.env.MONGODB_URI;

type MongooseCache = { conn: typeof mongoose | null; promise: Promise<typeof mongoose> | null };
declare global { var mongooseCache: MongooseCache | undefined; }

const cache = global.mongooseCache ?? (global.mongooseCache = { conn: null, promise: null });

export async function connectDB() {
  if (cache.conn) return cache.conn;
  const uri = MONGODB_URI();
  if (!uri) throw new Error("Missing MONGODB_URI environment variable");
  if (!cache.promise) {
    cache.promise = mongoose.connect(uri, { bufferCommands: false, maxPoolSize: 10 });
  }
  cache.conn = await cache.promise;
  return cache.conn;
}
