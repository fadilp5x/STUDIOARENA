import { isIP } from "node:net";
import { NextResponse } from "next/server";

export function jsonError(message: string, status = 400, details?: unknown) {
  return NextResponse.json({ error: message, ...(details ? { details } : {}) }, { status });
}

export function requireHttpsUrl(raw: string) {
  const url = new URL(raw);
  if (url.protocol !== "https:") throw new Error("Provider URLs must use HTTPS");
  const hostname = url.hostname.toLowerCase().replace(/^\[|\]$/g, "");
  if (isIP(hostname) || hostname === "localhost" || hostname.endsWith(".localhost") || hostname.endsWith(".local") || hostname.endsWith(".internal")) {
    throw new Error("Private, local and IP-literal provider URLs are not allowed");
  }
  if (url.username || url.password) throw new Error("Provider URLs must not contain embedded credentials");
  url.hash = "";
  return url.toString().replace(/\/$/, "");
}

export function upstreamStatus(error: unknown, fallback = 502) {
  const match = error instanceof Error ? error.message.match(/(?:^|\s)(\d{3}):/) : null;
  const code = match ? Number(match[1]) : 0;
  return [400, 401, 403, 404, 409, 413, 422, 429, 500, 502, 503, 504].includes(code) ? code : fallback;
}

export function safeError(error: unknown) {
  return error instanceof Error ? error.message : "Unexpected server error";
}
