type Bucket = { count: number; resetAt: number };
const buckets = new Map<string, Bucket>();
let lastSweep = 0;

// Lightweight per-process guard. Use a shared Redis limiter for multi-instance production deployments.
export function allowRequest(key: string, limit = 30, windowMs = 60_000) {
  const now = Date.now();
  if (now - lastSweep > 5 * 60_000) {
    for (const [entry, bucket] of buckets) if (bucket.resetAt <= now) buckets.delete(entry);
    lastSweep = now;
  }
  const bucket = buckets.get(key);
  if (!bucket || bucket.resetAt <= now) {
    buckets.set(key, { count: 1, resetAt: now + windowMs });
    return true;
  }
  if (bucket.count >= limit) return false;
  bucket.count += 1;
  return true;
}

export function requestClientKey(request: Request) {
  // Trust this only behind a hosting proxy that overwrites forwarding headers.
  const forwarded = request.headers.get("x-forwarded-for")?.split(",")[0]?.trim();
  const realIp = request.headers.get("x-real-ip")?.trim();
  return realIp || forwarded || "unknown-client";
}
