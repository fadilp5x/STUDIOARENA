import { decryptSecret } from "@/lib/crypto";
import { Connection } from "@/models";

export type ProviderConnection = {
  id: string;
  provider: string;
  label: string;
  baseUrl: string;
  apiKey: string;
  active: boolean;
};

export async function getActiveSeedanceConnection(userId: string): Promise<ProviderConnection> {
  return getSeedanceConnection(userId);
}

export async function getSeedanceConnection(userId: string, connectionId?: string | null): Promise<ProviderConnection> {
  if (connectionId === "env-fallback") {
    const apiKey = process.env.SEEDANCE_API_KEY;
    if (!apiKey) throw new Error("The environment Seedance key used by this task is no longer configured");
    return { id: "env-fallback", provider: "seedance", label: "Environment fallback", baseUrl: process.env.SEEDANCE_API_BASE_URL || process.env.SEEDANCE_BASE_URL || "https://open.fast-api.org", apiKey, active: true };
  }
  const query = connectionId
    ? { _id: connectionId, userId, provider: "seedance" }
    : { userId, provider: "seedance", active: true, enabled: true };
  const connection = await Connection.findOne(query).sort({ updatedAt: -1 });
  if (!connection && connectionId) throw new Error("The API connection used for this task was deleted. Restore the same provider key to continue polling.");
  if (connection) {
    return {
      id: String(connection._id), provider: connection.provider, label: connection.label,
      baseUrl: connection.baseUrl, apiKey: decryptSecret(connection.secret), active: true,
    };
  }
  const apiKey = process.env.SEEDANCE_API_KEY;
  if (!apiKey) throw new Error("No active Seedance API key. Add one in Settings → API Keys.");
  return { id: "env-fallback", provider: "seedance", label: "Environment fallback", baseUrl: process.env.SEEDANCE_API_BASE_URL || process.env.SEEDANCE_BASE_URL || "https://open.fast-api.org", apiKey, active: true };
}

export async function seedanceRequest(connection: ProviderConnection, path: string, init: RequestInit = {}) {
  const method = (init.method || "GET").toUpperCase();
  const attempts = method === "GET" ? 3 : 1;
  let lastError: Error | null = null;
  for (let attempt = 0; attempt < attempts; attempt += 1) {
    try {
      const response = await fetch(`${connection.baseUrl.replace(/\/$/, "")}${path}`, {
        ...init,
        headers: {
          Authorization: `Bearer ${connection.apiKey}`,
          ...(init.body && !(init.body instanceof FormData) ? { "Content-Type": "application/json" } : {}),
          ...(init.headers || {}),
        },
        cache: "no-store",
      });
      const raw = await response.text();
      let body: any;
      try { body = raw ? JSON.parse(raw) : {}; } catch { body = { message: raw }; }
      if (!response.ok) {
        const message = body?.error?.message || body?.message || body?.error || `Seedance API request failed (${response.status})`;
        const error = new Error(`${response.status}: ${String(message)}`);
        if (method === "GET" && [429, 504].includes(response.status) && attempt < attempts - 1) {
          await new Promise(resolve => setTimeout(resolve, 1200 * (attempt + 1)));
          continue;
        }
        throw error;
      }
      return body;
    } catch (error) {
      lastError = error instanceof Error ? error : new Error("Seedance request failed");
      const isRetryable = /^(429|504):/.test(lastError.message);
      if (!(method === "GET" && isRetryable && attempt < attempts - 1)) throw lastError;
      await new Promise(resolve => setTimeout(resolve, 1200 * (attempt + 1)));
    }
  }
  throw lastError || new Error("Seedance request failed");
}

export function seedanceAssetAction(baseUrl: string) {
  return `${baseUrl.replace(/\/$/, "")}/?Action=`;
}
