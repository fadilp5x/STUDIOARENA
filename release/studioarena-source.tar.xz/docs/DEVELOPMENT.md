# Development notes

## Environment variables

See `.env.example`. Do not commit actual values.

## Local quality checks

```bash
npm install
npm run typecheck
npm run build
```

## Adding a provider

1. Add its identifier and credential validation to the connection schema.
2. Add a dedicated adapter file implementing provider-specific request and response handling.
3. Declare supported generation modes and model capabilities.
4. Add a connection test that does not create billable jobs.
5. Add integration tests with mocked provider responses.
6. Keep the browser contract normalized and do not expose secrets.

## Known boundaries

- Current provider adapter is Seedance only; `custom` is an encrypted credential placeholder until an adapter is written.
- The UI has a chat preview and task polling, but polling currently occurs only while the page is open. Use a worker or scheduled job for guaranteed archival.
- The API guide does not define a reliable task percentage. The UI shows queued/running states rather than inventing percentage completion.
- The API guide does not define credit pricing; no credit balance is simulated.
- The Asset screen exposes local records. Seedance remote asset create/get is implemented; full remote asset list/update/delete screens remain an extension.
