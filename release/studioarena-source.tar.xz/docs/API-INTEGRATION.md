# API Integration Notes

## Seedance gateway

Base URL: `https://open.fast-api.org` (override with an encrypted per-user connection). Authentication: `Authorization: Bearer <key>`.

The request fields used by the Studio UI are grounded in the supplied gateway guide: `model`, `content`, `resolution`, `ratio`, `duration` or `frames`, `generate_audio`, `watermark`, `output_format`, `seed`, `camera_fixed`, `return_last_frame`, `service_tier` and `draft=false`. Duration and frames are exclusive. Image references support `first_frame`, `last_frame` and `reference_image` roles. The audio control accepts an HTTPS public reference URL; audio file upload is not part of the documented YourImageShare integration.

The sample model ID in the guide is `doubao-seedance-2-0-mini-260615`. The app uses this as its default. Add other model IDs only after confirming the account and gateway expose them.

## YourImageShare

Base URL: `https://yourimageshare.com/api`. Authentication: `X-API-Key`. Uploads are `multipart/form-data`; JSON responses carry the media record.

- Direct image/video upload: `POST /` with `uploads` (one file per request, up to 100 MB).
- Chunk: `POST /chunk` with a unique `upload_id`, zero-based `index`, `total` and `chunk` (5 MB chunks, 200 MB total ceiling).
- Finalize a chunked upload: `POST /` with `upload_id`, `filename` and optional metadata fields.
- Import remote generation results: `POST /` with `url`.
- List: `GET /?page=N`.
- Delete: `DELETE /{id}`.

Use `src` as the stable direct file URL. `path` may change after post-upload conversion. The API docs distinguish full API keys from upload-only keys; this app's connection test, list/delete workflow and result archival require a full key.

## Error behavior

Seedance may pass through upstream status and error codes. The app surfaces error messages to the authenticated user and retains the local record if a poll request temporarily fails. Add exponential backoff and a durable worker before production scale. YourImageShare errors are returned as upload or archival errors; failed archival leaves the temporary Seedance URL as a fallback where available.
