# Security and data handling

## Secrets

- Provider keys are encrypted server-side with AES-256-GCM.
- Each secret uses a fresh random 12-byte IV and stores its authentication tag.
- The encryption key is supplied through `APP_ENCRYPTION_KEY`, not source code.
- Only a masked last-four representation is returned by the connection list API.
- Do not use `NEXT_PUBLIC_` for provider credentials.

## Authentication

- Passwords are hashed with bcrypt (12 rounds).
- Sessions are signed JWTs inside HTTP-only, SameSite=Lax cookies.
- Production cookies are Secure.
- All user-owned records are scoped by `userId` in route queries.

## Media

- The app forwards file bytes to YourImageShare.
- MongoDB stores only references and metadata. It does not store image/video/audio binary data or GridFS chunks.
- Default media visibility is unlisted. An unlisted file's URL is effectively a bearer link; treat it as shareable by anyone who obtains it.
- The YourImageShare API key is used only by server routes.

## Required operational controls

Before public use, add distributed rate limiting, login throttling, email verification, password reset, malware/content scanning, security headers, audit logs with secret redaction, a privacy/retention policy and monitored archival retries. Configure provider request limits and upload size limits at the hosting layer.
