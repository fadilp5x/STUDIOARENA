# Architecture

## Runtime boundaries

- **Browser:** UI state, form inputs, local attachment previews, session requests. It never receives provider API secrets.
- **Next.js route handlers:** authentication, schema validation, provider selection, API calls, upload forwarding, polling and archival.
- **MongoDB:** users, encrypted API credentials, asset metadata, task metadata, chat messages and projects. No binary media payloads.
- **YourImageShare:** durable media storage for image/video/audio inputs and archived generation outputs.
- **Seedance gateway:** generation tasks and remote asset registry.

## Key data flows

### Upload

1. Browser sends a `File` to `POST /api/uploads`.
2. Route validates MIME family and size (200 MB ceiling).
3. For files through 100 MB, upload directly to YourImageShare. For larger files, send 5 MB chunks and finalize the upload.
4. Save the returned YourImageShare ID, `src`, `thumb`, type, dimensions and size to MongoDB.
5. Return metadata to the browser. The media bytes are not written to MongoDB.

### Generate

1. Browser submits a prompt, model, settings and owned asset IDs to `POST /api/generations`.
2. Backend resolves the currently active Seedance connection and decrypts its key in memory.
3. Backend loads only assets belonging to the authenticated user and constructs the Seedance `content[]` payload.
4. Backend creates the upstream task, then stores the task ID and chat message metadata.
5. Browser polls `GET /api/generations/:id` while the Studio screen is active.
6. Backend polls the same saved provider connection that created the task.
7. On success, the backend asks YourImageShare to import the temporary result URL and stores its stable `src` URL.

### Reference asset sync

1. User selects **Sync to Seedance** on an asset.
2. Backend creates a Seedance asset group once per user, then creates a remote asset using the YourImageShare `src` URL.
3. Backend queries GetAsset and saves its processing status.
4. Asset references are sent as `asset://asset-id` only after the remote status is `Active`; otherwise the public YourImageShare URL remains available as a fallback.

## Provider abstraction

`lib/provider.ts` is the Seedance adapter boundary. `lib/yourimageshare.ts` is the media-storage adapter. Future providers should expose a normalized internal interface:

- `createGeneration(input)`
- `getGeneration(remoteId)`
- `listGenerations(filters)`
- `deleteGeneration(remoteId)` when supported
- `capabilities` describing modes, duration/frame options, aspect ratios, resolutions, and audio support

Do not send Seedance-only options to another provider unless its own adapter declares support.
