import type { Metadata, Viewport } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Seedance Studio — Create without limits",
  description: "A multi-provider AI video workspace with Seedance generation, asset management and chat-based previews.",
  applicationName: "Seedance Studio",
};

export const viewport: Viewport = { width: "device-width", initialScale: 1, themeColor: "#090D18" };

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="en"><body>{children}</body></html>;
}
