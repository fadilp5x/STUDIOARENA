import { NextRequest, NextResponse } from "next/server";
import { Types } from "mongoose";
import { getSessionUserId } from "@/lib/auth";
import { connectDB } from "@/lib/mongodb";
import { getSeedanceConnection, seedanceRequest } from "@/lib/provider";
import { decryptSecret } from "@/lib/crypto";
import { importRemoteMedia } from "@/lib/yourimageshare";
import { jsonError } from "@/lib/http";
import { Asset, Connection, Conversation, Generation } from "@/models";

export const runtime = "nodejs";
export const maxDuration = 120;
type Context = { params: Promise<{ id: string }> };

async function yourImageShareConnection(userId: string) {
  const connection = await Connection.findOne({ userId, provider: "yourimageshare", active: true, enabled: true });
  return connection ? { id: String(connection._id), key: decryptSecret(connection.secret), baseUrl: connection.baseUrl } : { id: "env-fallback", key: process.env.YOURIMAGESHARE_API_KEY, baseUrl: process.env.YOURIMAGESHARE_BASE_URL };
}

export async function GET(_request: NextRequest, context: Context) {
  const userId = await getSessionUserId();
  if (!userId) return jsonError("Authentication required", 401);
  const { id } = await context.params;
  if (!Types.ObjectId.isValid(id)) return jsonError("Invalid record ID", 400);
  await connectDB();
  const generation = await Generation.findOne({ _id: id, userId });
  if (!generation) return jsonError("Generation not found", 404);
  if (["queued", "running"].includes(generation.status)) {
    try {
      const connection = await getSeedanceConnection(userId, generation.connectionId);
      const remote = await seedanceRequest(connection, `/api/v3/contents/generations/tasks/${encodeURIComponent(generation.remoteTaskId)}`);
      generation.status = remote.status || generation.status;
      generation.videoUrl = remote.content?.video_url || generation.videoUrl;
      generation.lastFrameUrl = remote.content?.last_frame_url || generation.lastFrameUrl;
      generation.errorMessage = remote.error?.message || null;
      if (generation.status === "succeeded" && !generation.videoUrl) generation.errorMessage = "The task succeeded, but the gateway did not return a video URL.";
      generation.usage = remote.usage || generation.usage;
      if (generation.status === "succeeded" && generation.videoUrl && !generation.storedVideoUrl) {
        const yis = await yourImageShareConnection(userId);
        if (yis.key) {
          try {
            const uploaded = await importRemoteMedia(generation.videoUrl, `Seedance-${generation.remoteTaskId}`, yis.key, yis.baseUrl);
            generation.storedVideoUrl = uploaded.src || null;
            if (generation.storedVideoUrl && uploaded.id) {
              await Asset.findOneAndUpdate({ userId, externalId: uploaded.id }, { $set: { storageConnectionId: yis.id, type: "video", title: `Generation ${generation.remoteTaskId}`.slice(0, 90), src: generation.storedVideoUrl, thumb: uploaded.thumb || null, size: uploaded.size || null, visibility: uploaded.visibility || "unlisted" } }, { new: true, upsert: true });
            }
          } catch (error) {
            generation.errorMessage = `Video succeeded but archival to YourImageShare failed: ${error instanceof Error ? error.message : "upload error"}`;
          }
        }
      }
      if (generation.status === "succeeded" && generation.lastFrameUrl && !generation.storedLastFrameUrl) {
        const yis = await yourImageShareConnection(userId);
        if (yis.key) {
          try {
            const frame = await importRemoteMedia(generation.lastFrameUrl, `Last-frame-${generation.remoteTaskId}`, yis.key, yis.baseUrl);
            generation.storedLastFrameUrl = frame.src || null;
            if (frame.src && frame.id) await Asset.findOneAndUpdate({ userId, externalId: frame.id }, { $set: { storageConnectionId: yis.id, type: "image", title: `Last frame ${generation.remoteTaskId}`.slice(0, 90), src: frame.src, thumb: frame.thumb || null, visibility: frame.visibility || "unlisted" } }, { new: true, upsert: true });
          } catch { /* Keep the original temporary last-frame URL as a fallback. */ }
        }
      }
      await generation.save();
      if (generation.conversationId) {
        const conversation = await Conversation.findOne({ _id: generation.conversationId, userId });
        if (conversation) {
          const msg = conversation.messages.find((m: any) => String(m.generationId) === String(generation._id));
          if (msg) {
            msg.status = generation.status;
            msg.content = generation.status === "succeeded" ? "Your video is ready." : generation.status === "failed" ? generation.errorMessage || "Generation failed." : `Generation ${generation.status}.`;
            await conversation.save();
          }
        }
      }
    } catch (error) {
      // Return the last known task state; transient upstream errors should not erase the local record.
      return NextResponse.json({ generation: serialize(generation), refreshError: error instanceof Error ? error.message : "Task refresh failed" });
    }
  }
  return NextResponse.json({ generation: serialize(generation) });
}

function serialize(item: any) {
  return {
    id: String(item._id), taskId: item.remoteTaskId, status: item.status, prompt: item.prompt, projectId: item.projectId ? String(item.projectId) : null, outputFormat: item.outputFormat,
    model: item.model, mode: item.mode, videoUrl: item.storedVideoUrl || item.videoUrl,
    temporaryVideoUrl: item.storedVideoUrl ? null : item.videoUrl,
    lastFrameUrl: item.storedLastFrameUrl || item.lastFrameUrl,
    errorMessage: item.errorMessage, createdAt: item.createdAt,
    resolution: item.resolution, ratio: item.ratio, duration: item.duration, frames: item.frames,
    usage: item.usage,
  };
}

export async function DELETE(_request: NextRequest, context: Context) {
  const userId = await getSessionUserId();
  if (!userId) return jsonError("Authentication required", 401);
  const { id } = await context.params;
  if (!Types.ObjectId.isValid(id)) return jsonError("Invalid record ID", 400);
  await connectDB();
  const generation = await Generation.findOne({ _id: id, userId });
  if (!generation) return jsonError("Generation not found", 404);
  if (!["succeeded", "failed"].includes(generation.status)) return jsonError("Only completed tasks can be deleted. The upstream API cannot cancel running tasks.", 409);
  try {
    const connection = await getSeedanceConnection(userId, generation.connectionId);
    await seedanceRequest(connection, `/api/v3/contents/generations/tasks/${encodeURIComponent(generation.remoteTaskId)}`, { method: "DELETE" });
  } catch (error) {
    return jsonError(error instanceof Error ? error.message : "Could not delete remote task", 502);
  }
  await generation.deleteOne();
  return NextResponse.json({ ok: true });
}
