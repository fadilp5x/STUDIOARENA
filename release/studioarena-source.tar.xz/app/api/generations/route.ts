import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { Types } from "mongoose";
import { getSessionUserId } from "@/lib/auth";
import { connectDB } from "@/lib/mongodb";
import { getActiveSeedanceConnection, seedanceRequest } from "@/lib/provider";
import { jsonError, requireHttpsUrl, upstreamStatus } from "@/lib/http";
import { allowRequest } from "@/lib/rate-limit";
import { Asset, Conversation, Generation, Project } from "@/models";

export const runtime = "nodejs";

const schema = z.object({
  prompt: z.string().min(3).max(12000),
  model: z.string().min(3).max(120),
  mode: z.enum(["text-to-video", "image-to-video", "video-to-video", "audio-driven", "multi-modal"]).default("text-to-video"),
  assetIds: z.array(z.string()).max(8).default([]),
  assetRoles: z.record(z.string(), z.enum(["first_frame", "last_frame", "reference_image"])).optional(),
  projectId: z.string().optional(),
  audioReferenceUrl: z.string().url().optional().or(z.literal("")),
  resolution: z.enum(["480p", "720p", "1080p"]).default("720p"),
  ratio: z.enum(["16:9", "9:16", "1:1", "3:4", "4:3", "adaptive"]).default("16:9"),
  duration: z.number().int().min(1).optional(),
  frames: z.number().int().min(1).optional(),
  outputFormat: z.enum(["mp4", "mov"]).default("mp4"),
  serviceTier: z.enum(["default", "flex"]).default("default"),
  generateAudio: z.boolean().default(true),
  watermark: z.boolean().default(false),
  seed: z.number().int().optional().default(-1),
  cameraFixed: z.boolean().default(false),
  returnLastFrame: z.boolean().default(false),
  conversationId: z.string().optional(),
});

export async function GET(request: NextRequest) {
  const userId = await getSessionUserId();
  if (!userId) return jsonError("Authentication required", 401);
  await connectDB();
  if (request.nextUrl.searchParams.get("remote") === "1") {
    try {
      const requestedPage = Number(request.nextUrl.searchParams.get("page_num") || 1);
      const requestedSize = Number(request.nextUrl.searchParams.get("page_size") || 20);
      const pageNum = Number.isFinite(requestedPage) ? Math.max(1, Math.min(500, requestedPage)) : 1;
      const pageSize = Number.isFinite(requestedSize) ? Math.max(1, Math.min(100, requestedSize)) : 20;
      const query = new URLSearchParams({ page_num: String(pageNum), page_size: String(pageSize) });
      const modelFilter = request.nextUrl.searchParams.get("model");
      if (modelFilter) query.set("filter.model", modelFilter.slice(0, 120));
      for (const status of request.nextUrl.searchParams.getAll("status")) query.append("filter.status", status);
      const connection = await getActiveSeedanceConnection(userId);
      const remote = await seedanceRequest(connection, `/api/v3/contents/generations/tasks?${query.toString()}`);
      return NextResponse.json({ source: "seedance", items: remote.items || [], total: remote.total ?? remote.data?.total ?? null, pageNum, pageSize });
    } catch (error) {
      return jsonError(error instanceof Error ? error.message : "Could not load Seedance task history", 502);
    }
  }
  const items = await Generation.find({ userId }).sort({ createdAt: -1 }).limit(60).lean();
  return NextResponse.json({ generations: items.map(item => ({ ...item, id: String(item._id), videoUrl: item.storedVideoUrl || item.videoUrl, conversationId: item.conversationId ? String(item.conversationId) : null })) });
}

export async function POST(request: NextRequest) {
  const userId = await getSessionUserId();
  if (!userId) return jsonError("Authentication required", 401);
  if (!allowRequest(`generation:${userId}`, 8, 60_000)) return jsonError("Generation rate limit reached. Try again shortly.", 429);
  try {
    const input = schema.parse(await request.json());
    if (input.duration !== undefined && input.frames !== undefined) return jsonError("Duration and frame count are mutually exclusive", 400);
    if (input.audioReferenceUrl) requireHttpsUrl(input.audioReferenceUrl);
    if (input.assetIds.some(id => !Types.ObjectId.isValid(id))) return jsonError("One or more selected assets have invalid IDs", 400);
    if (input.projectId && !Types.ObjectId.isValid(input.projectId)) return jsonError("Selected project ID is invalid", 400);
    await connectDB();
    const assets = input.assetIds.length ? await Asset.find({ _id: { $in: input.assetIds }, userId }) : [];
    if (assets.length !== input.assetIds.length) return jsonError("One or more selected assets are unavailable", 400);
    const connection = await getActiveSeedanceConnection(userId);
    const project = input.projectId ? await Project.findOne({ _id: input.projectId, userId }) : null;
    if (input.projectId && !project) return jsonError("Selected project was not found", 404);
    if (input.mode === "image-to-video" && !assets.some(a => a.type === "image")) return jsonError("Image-to-video needs at least one attached image", 400);
    if (input.mode === "video-to-video" && !assets.some(a => a.type === "video")) return jsonError("Video-to-video needs an attached video", 400);
    if (input.mode === "audio-driven" && !input.audioReferenceUrl) return jsonError("Audio-driven mode needs a public audio reference URL", 400);

    const content: any[] = [{ type: "text", text: input.prompt }];
    if (input.audioReferenceUrl) content.push({ type: "audio_url", audio_url: { url: input.audioReferenceUrl }, role: "reference_audio" });
    for (const asset of assets) {
      const mirrorMatchesKey = asset.seedanceAssetId && asset.seedanceConnectionId === connection.id;
      if (mirrorMatchesKey && asset.seedanceStatus !== "Active") return jsonError(`Asset "${asset.title}" is still processing in Seedance. Wait until it is Active, or use its YourImageShare URL directly.`, 409);
      const source = mirrorMatchesKey ? `asset://${asset.seedanceAssetId}` : asset.src;
      if (asset.type === "image") content.push({ type: "image_url", image_url: { url: source }, role: input.assetRoles?.[String(asset._id)] || (input.mode === "image-to-video" ? "first_frame" : "reference_image") });
      else if (asset.type === "video") content.push({ type: "video_url", video_url: { url: source } });
      else if (asset.type === "audio") content.push({ type: "audio_url", audio_url: { url: source }, role: "reference_audio" });
    }

    const payload: Record<string, unknown> = {
      model: input.model,
      content,
      resolution: input.resolution,
      ratio: input.ratio,
      generate_audio: input.generateAudio,
      watermark: input.watermark,
      seed: input.seed,
      camera_fixed: input.cameraFixed,
      return_last_frame: input.returnLastFrame,
      output_format: input.outputFormat,
      service_tier: input.serviceTier,
      draft: false,
    };
    if (input.frames) payload.frames = input.frames;
    else payload.duration = input.duration ?? 5;

    const response = await seedanceRequest(connection, "/api/v3/contents/generations/tasks", { method: "POST", body: JSON.stringify(payload) });
    const remoteTaskId = response.id || response.task_id;
    if (!remoteTaskId) return jsonError("Seedance did not return a task ID", 502, response);

    let conversation = input.conversationId && Types.ObjectId.isValid(input.conversationId)
      ? await Conversation.findOne({ _id: input.conversationId, userId }) : null;
    if (!conversation) conversation = await Conversation.create({ userId, title: input.prompt.slice(0, 70), messages: [] });
    conversation.messages.push({ role: "user", content: input.prompt, createdAt: new Date(), attachments: assets.map(a => ({ id: String(a._id), type: a.type, name: a.title, src: a.src, thumb: a.thumb })) } as any);

    const generation = await Generation.create({
      userId, conversationId: conversation._id, projectId: project?._id || null, provider: "seedance", connectionId: connection.id,
      remoteTaskId, model: input.model, mode: input.mode, prompt: input.prompt,
      status: "queued", resolution: input.resolution, ratio: input.ratio,
      duration: input.frames ? null : input.duration ?? 5, frames: input.frames || null, outputFormat: input.outputFormat, serviceTier: input.serviceTier,
      generateAudio: input.generateAudio, watermark: input.watermark, seed: input.seed,
      cameraFixed: input.cameraFixed, returnLastFrame: input.returnLastFrame, sourceAssets: assets.map(a => a._id),
    });
    conversation.messages.push({ role: "assistant", content: "Your generation has been queued.", createdAt: new Date(), generationId: generation._id, status: "queued", attachments: [] } as any);
    await conversation.save();
    return NextResponse.json({ generation: { id: String(generation._id), taskId: remoteTaskId, status: generation.status, model: generation.model }, conversationId: String(conversation._id) }, { status: 201 });
  } catch (error) {
    if (error instanceof z.ZodError) return jsonError("Invalid generation settings", 400, error.issues);
    return jsonError(error instanceof Error ? error.message : "Generation request failed", upstreamStatus(error));
  }
}
