import { NextResponse } from "next/server";
import { Types } from "mongoose";
import { getSessionUserId } from "@/lib/auth";
import { connectDB } from "@/lib/mongodb";
import { getActiveSeedanceConnection, seedanceRequest } from "@/lib/provider";
import { Asset, Connection, User } from "@/models";
import { jsonError, upstreamStatus } from "@/lib/http";

export const runtime = "nodejs";
type Context = { params: Promise<{ id: string }> };

async function assetAction(connection: Awaited<ReturnType<typeof getActiveSeedanceConnection>>, action: string, body: Record<string, unknown>) {
  const query = `/?Action=${encodeURIComponent(action)}&Version=2024-01-01`;
  return seedanceRequest(connection, query, { method: "POST", body: JSON.stringify(body) });
}

export async function POST(_request: Request, context: Context) {
  const userId = await getSessionUserId();
  if (!userId) return jsonError("Authentication required", 401);
  const { id } = await context.params;
  if (!Types.ObjectId.isValid(id)) return jsonError("Invalid record ID", 400);
  await connectDB();
  const [asset, user] = await Promise.all([Asset.findOne({ _id: id, userId }), User.findById(userId)]);
  if (!asset || !user) return jsonError("Asset or user not found", 404);
  if (!asset.src) return jsonError("The asset has no public source URL", 400);
  try {
    const connection = await getActiveSeedanceConnection(userId);
    const connectionRecord = connection.id === "env-fallback" ? null : await Connection.findOne({ _id: connection.id, userId, provider: "seedance" });
    if (connection.id !== "env-fallback" && !connectionRecord) throw new Error("The active Seedance connection could not be found");
    let groupId = connectionRecord?.seedanceAssetGroupId || (connection.id === "env-fallback" ? user.seedanceAssetGroupId : null);
    if (!groupId) {
      const group = await assetAction(connection, "CreateAssetGroup", { Name: "Seedance Studio Assets", GroupType: "AIGC", ProjectName: "default" });
      groupId = group.Result?.Id || group.Result?.id || group.Id;
      if (!groupId) throw new Error("Seedance did not return an asset group ID");
      if (connectionRecord) { connectionRecord.seedanceAssetGroupId = groupId; await connectionRecord.save(); }
      else { user.seedanceAssetGroupId = groupId; await user.save(); }
    }
    const mirrorMatchesActiveKey = asset.seedanceConnectionId === connection.id;
    if (!asset.seedanceAssetId || !mirrorMatchesActiveKey) {
      const type = asset.type === "image" ? "Image" : asset.type === "video" ? "Video" : asset.type === "audio" ? "Audio" : "Model";
      const created = await assetAction(connection, "CreateAsset", { GroupId: groupId, Name: asset.title.slice(0, 90), AssetType: type, URL: asset.src, ProjectName: "default" });
      asset.seedanceAssetId = created.Result?.Id || created.Result?.id || created.Id;
      if (!asset.seedanceAssetId) throw new Error("Seedance did not return an asset ID");
      asset.seedanceConnectionId = connection.id;
    }
    const detail = await assetAction(connection, "GetAsset", { Id: asset.seedanceAssetId });
    asset.seedanceStatus = detail.Result?.Status || detail.Result?.status || "Processing";
    await asset.save();
    return NextResponse.json({ assetId: asset.seedanceAssetId, status: asset.seedanceStatus, connectionId: connection.id, message: asset.seedanceStatus === "Active" ? "Ready to use" : "Seedance is processing this asset" });
  } catch (error) {
    return jsonError(error instanceof Error ? error.message : "Could not register asset with Seedance", upstreamStatus(error));
  }
}
