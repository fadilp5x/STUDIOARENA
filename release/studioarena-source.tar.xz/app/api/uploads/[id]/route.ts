import { NextResponse } from "next/server";
import { Types } from "mongoose";
import { getSessionUserId } from "@/lib/auth";
import { connectDB } from "@/lib/mongodb";
import { decryptSecret } from "@/lib/crypto";
import { deleteRemoteMedia } from "@/lib/yourimageshare";
import { Asset, Connection } from "@/models";
import { jsonError, upstreamStatus } from "@/lib/http";

export const runtime = "nodejs";
type Context = { params: Promise<{ id: string }> };
export async function DELETE(_request: Request, context: Context) {
  const userId = await getSessionUserId();
  if (!userId) return jsonError("Authentication required", 401);
  const { id } = await context.params;
  if (!Types.ObjectId.isValid(id)) return jsonError("Invalid record ID", 400);
  await connectDB();
  const asset = await Asset.findOne({ _id: id, userId });
  if (!asset) return jsonError("Asset not found", 404);
  const connection = asset.storageConnectionId && asset.storageConnectionId !== "env-fallback"
    ? await Connection.findOne({ _id: asset.storageConnectionId, userId, provider: "yourimageshare" })
    : null;
  if (asset.storageConnectionId && asset.storageConnectionId !== "env-fallback" && !connection) {
    return jsonError("The YourImageShare connection used for this asset was deleted. Restore that connection before deleting the remote file.", 409);
  }
  const key = connection ? decryptSecret(connection.secret) : process.env.YOURIMAGESHARE_API_KEY;
  if (!key) return jsonError("YourImageShare key is not configured", 503);
  try { await deleteRemoteMedia(asset.externalId, key, connection?.baseUrl); }
  catch (error) { return jsonError(error instanceof Error ? error.message : "YourImageShare delete failed", upstreamStatus(error)); }
  await asset.deleteOne();
  return NextResponse.json({ ok: true });
}
