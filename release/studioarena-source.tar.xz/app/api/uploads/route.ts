import { NextRequest, NextResponse } from "next/server";
import { getSessionUserId } from "@/lib/auth";
import { connectDB } from "@/lib/mongodb";
import { decryptSecret } from "@/lib/crypto";
import { uploadMedia } from "@/lib/yourimageshare";
import { Asset, Connection } from "@/models";
import { jsonError, upstreamStatus } from "@/lib/http";
import { allowRequest } from "@/lib/rate-limit";

export const runtime = "nodejs";
export const maxDuration = 120;

async function activeYisConnection(userId: string) {
  const connection = await Connection.findOne({ userId, provider: "yourimageshare", active: true, enabled: true }).sort({ updatedAt: -1 });
  return connection ? { id: String(connection._id), key: decryptSecret(connection.secret), baseUrl: connection.baseUrl } : undefined;
}

export async function GET() {
  const userId = await getSessionUserId();
  if (!userId) return jsonError("Authentication required", 401);
  await connectDB();
  const items = await Asset.find({ userId }).sort({ createdAt: -1 }).limit(100).lean();
  return NextResponse.json({ assets: items.map(x => ({ ...x, id: String(x._id) })) });
}

export async function POST(request: NextRequest) {
  const userId = await getSessionUserId();
  if (!userId) return jsonError("Authentication required", 401);
  if (!allowRequest(`upload:${userId}`, 20, 60_000)) return jsonError("Upload rate limit reached. Try again shortly.", 429);
  try {
    await connectDB();
    const form = await request.formData();
    const file = form.get("file");
    if (!(file instanceof File)) return jsonError("A media file is required", 400);
    const extension = file.name.split(".").pop()?.toLowerCase() || "";
    const supported = new Set(["jpg", "jpeg", "png", "gif", "webp", "avif", "bmp", "tif", "tiff", "heic", "heif", "mp4", "webm", "avi", "mov", "mkv", "mpeg", "mpg", "wmv", "flv", "3gp"]);
    if (!supported.has(extension)) return jsonError("Unsupported format. Upload JPG, PNG, GIF, WebP, AVIF, BMP, TIFF, HEIC/HEIF or a supported video format. Audio must be supplied as a public reference URL.", 415);
    const yis = await activeYisConnection(userId);
    const uploaded = await uploadMedia(file, String(form.get("title") || file.name), yis?.key, yis?.baseUrl);
    const type = uploaded.type === "video" ? "video" : uploaded.type === "image" ? "image" : "file";
    if (!uploaded.id || !uploaded.src || !["image", "video"].includes(type)) return jsonError("YourImageShare returned an incomplete media record", 502);
    const asset = await Asset.findOneAndUpdate(
      { userId, externalId: uploaded.id },
      { $set: {
        storageConnectionId: yis?.id || "env-fallback", type, title: String(uploaded.title || form.get("title") || file.name).slice(0, 90),
        src: uploaded.src, thumb: uploaded.thumb || null, direct: uploaded.direct || null,
        width: uploaded.width || null, height: uploaded.height || null, size: uploaded.size || file.size,
        visibility: uploaded.visibility || "unlisted", expiresAt: uploaded.expires_at ? new Date(uploaded.expires_at) : null,
      } },
      { new: true, upsert: true, setDefaultsOnInsert: true },
    );
    return NextResponse.json({ asset: { id: String(asset._id), externalId: asset.externalId, type: asset.type, title: asset.title, src: asset.src, thumb: asset.thumb, size: asset.size } }, { status: 201 });
  } catch (error) {
    return jsonError(error instanceof Error ? error.message : "Upload failed", upstreamStatus(error));
  }
}
