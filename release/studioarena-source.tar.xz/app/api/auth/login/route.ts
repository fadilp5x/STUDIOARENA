import { NextRequest, NextResponse } from "next/server";
import bcrypt from "bcryptjs";
import { z } from "zod";
import { connectDB } from "@/lib/mongodb";
import { createSession } from "@/lib/auth";
import { User } from "@/models";
import { jsonError } from "@/lib/http";
import { allowRequest, requestClientKey } from "@/lib/rate-limit";

export const runtime = "nodejs";
const schema = z.object({ email: z.string().email(), password: z.string().min(1) });

export async function POST(request: NextRequest) {
  if (!allowRequest(`login:${requestClientKey(request)}`, 8, 60_000)) return jsonError("Too many sign-in attempts. Try again in a minute.", 429);
  try {
    const input = schema.parse(await request.json());
    await connectDB();
    const user = await User.findOne({ email: input.email.toLowerCase().trim() }).select("+passwordHash");
    if (!user || !(await bcrypt.compare(input.password, user.passwordHash))) return jsonError("Invalid email or password", 401);
    await createSession(String(user._id));
    return NextResponse.json({ user: { id: String(user._id), name: user.name, email: user.email } });
  } catch (error) {
    return jsonError(error instanceof Error ? error.message : "Login failed", 400);
  }
}
