import { NextResponse } from "next/server";
import { getSessionUserId } from "@/lib/auth";
import { connectDB } from "@/lib/mongodb";
import { User } from "@/models";

export const runtime = "nodejs";
export async function GET() {
  const userId = await getSessionUserId();
  if (!userId) return NextResponse.json({ user: null }, { status: 401 });
  await connectDB();
  const user = await User.findById(userId).select("name email").lean();
  if (!user) return NextResponse.json({ user: null }, { status: 401 });
  return NextResponse.json({ user: { id: String(user._id), name: user.name, email: user.email } });
}
