import { NextRequest, NextResponse } from "next/server";
import bcrypt from "bcryptjs";
import { z } from "zod";
import { connectDB } from "@/lib/mongodb";
import { createSession } from "@/lib/auth";
import { User } from "@/models";
import { jsonError } from "@/lib/http";
import { allowRequest, requestClientKey } from "@/lib/rate-limit";

export const runtime = "nodejs";
const schema = z.object({ name: z.string().min(2).max(80), email: z.string().email().max(180), password: z.string().min(10).max(100) });

export async function POST(request: NextRequest) {
  if (!allowRequest(`register:${requestClientKey(request)}`, 4, 60_000)) return jsonError("Too many registration attempts. Try again in a minute.", 429);
  if (process.env.ALLOW_PUBLIC_REGISTRATION !== "true") return jsonError("Public registration is disabled. Ask the workspace owner to enable it.", 403);
  try {
    const input = schema.parse(await request.json());
    await connectDB();
    const email = input.email.toLowerCase().trim();
    if (await User.exists({ email })) return jsonError("An account with this email already exists", 409);
    const passwordHash = await bcrypt.hash(input.password, 12);
    const user = await User.create({ name: input.name.trim(), email, passwordHash });
    await createSession(String(user._id));
    return NextResponse.json({ user: { id: String(user._id), name: user.name, email: user.email } }, { status: 201 });
  } catch (error) {
    return jsonError(error instanceof Error ? error.message : "Registration failed", 400);
  }
}
