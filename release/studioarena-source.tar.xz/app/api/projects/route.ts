import { NextRequest, NextResponse } from "next/server";
import { getSessionUserId } from "@/lib/auth";
import { connectDB } from "@/lib/mongodb";
import { Project } from "@/models";
import { jsonError } from "@/lib/http";

export const runtime = "nodejs";
export async function GET() {
  const userId = await getSessionUserId();
  if (!userId) return jsonError("Authentication required", 401);
  await connectDB();
  const projects = await Project.find({ userId }).sort({ updatedAt: -1 }).lean();
  return NextResponse.json({ projects: projects.map(p => ({ ...p, id: String(p._id) })) });
}

export async function POST(request: NextRequest) {
  const userId = await getSessionUserId();
  if (!userId) return jsonError("Authentication required", 401);
  const body = await request.json().catch(() => ({}));
  const name = String(body.name || "").trim();
  if (name.length < 2 || name.length > 80) return jsonError("Project name must be between 2 and 80 characters", 400);
  await connectDB();
  const project = await Project.create({ userId, name, description: String(body.description || "").slice(0, 300), color: /^#[0-9a-f]{6}$/i.test(body.color) ? body.color : "#716BFF" });
  return NextResponse.json({ project: { id: String(project._id), name: project.name, description: project.description, color: project.color } }, { status: 201 });
}
