import { NextRequest, NextResponse } from "next/server";
import { getSessionUserId } from "@/lib/auth";
import { connectDB } from "@/lib/mongodb";
import { Conversation, Generation } from "@/models";
import { jsonError } from "@/lib/http";

export const runtime = "nodejs";
export async function GET() {
  const userId = await getSessionUserId();
  if (!userId) return jsonError("Authentication required", 401);
  await connectDB();
  const conversations = await Conversation.find({ userId }).sort({ updatedAt: -1 }).limit(25).lean();
  const conversationIds = conversations.map(c => c._id);
  const generations = await Generation.find({ userId, conversationId: { $in: conversationIds } }).lean();
  const generationMap = new Map(generations.map(g => [String(g._id), g]));
  return NextResponse.json({ conversations: conversations.map(c => ({
    id: String(c._id), title: c.title, updatedAt: c.updatedAt,
    messages: c.messages.map((m: any) => {
      const generation = m.generationId ? generationMap.get(String(m.generationId)) : null;
      return {
        id: String(m._id), role: m.role, content: m.content, status: m.status,
        attachments: m.attachments || [],
        generation: generation ? {
          id: String(generation._id), taskId: generation.remoteTaskId, status: generation.status,
          prompt: generation.prompt, model: generation.model, mode: generation.mode,
          videoUrl: generation.storedVideoUrl || generation.videoUrl,
          temporaryVideoUrl: generation.storedVideoUrl ? null : generation.videoUrl,
          lastFrameUrl: generation.storedLastFrameUrl || generation.lastFrameUrl,
          errorMessage: generation.errorMessage, createdAt: generation.createdAt,
          resolution: generation.resolution, ratio: generation.ratio, duration: generation.duration,
        } : null,
      };
    }),
  })) });
}

export async function POST(request: NextRequest) {
  const userId = await getSessionUserId();
  if (!userId) return jsonError("Authentication required", 401);
  const body = await request.json().catch(() => ({}));
  await connectDB();
  const conversation = await Conversation.create({ userId, title: String(body.title || "New creation").slice(0, 100), messages: [] });
  return NextResponse.json({ conversationId: String(conversation._id) }, { status: 201 });
}
