import { NextResponse } from "next/server";
import { Types } from "mongoose";
import { getSessionUserId } from "@/lib/auth";
import { connectDB } from "@/lib/mongodb";
import { decryptSecret } from "@/lib/crypto";
import { Connection } from "@/models";
import { jsonError } from "@/lib/http";
import { testYourImageShareKey } from "@/lib/yourimageshare";

export const runtime = "nodejs";
type Context = { params: Promise<{ id: string }> };

export async function POST(_request: Request, context: Context) {
  const userId = await getSessionUserId();
  if (!userId) return jsonError("Authentication required", 401);
  const { id } = await context.params;
  if (!Types.ObjectId.isValid(id)) return jsonError("Invalid record ID", 400);
  await connectDB();
  const item = await Connection.findOne({ _id: id, userId });
  if (!item) return jsonError("Connection not found", 404);
  try {
    const key = decryptSecret(item.secret);
    if (item.provider === "seedance") {
      const response = await fetch(`${item.baseUrl}/api/v3/contents/generations/tasks?page_num=1&page_size=1`, { headers: { Authorization: `Bearer ${key}` }, cache: "no-store" });
      if (!response.ok) throw new Error(`Seedance returned ${response.status}`);
    } else if (item.provider === "yourimageshare") {
      await testYourImageShareKey(key, item.baseUrl);
    } else {
      return NextResponse.json({ ok: false, status: "untested", message: "Custom provider adapters must be implemented before connectivity can be verified." });
    }
    item.connectionStatus = "connected"; item.lastTestedAt = new Date(); await item.save();
    return NextResponse.json({ ok: true, status: "connected" });
  } catch (error) {
    item.connectionStatus = "error"; item.lastTestedAt = new Date(); await item.save();
    return NextResponse.json({ ok: false, status: "error", message: error instanceof Error ? error.message : "Connection test failed" }, { status: 502 });
  }
}
