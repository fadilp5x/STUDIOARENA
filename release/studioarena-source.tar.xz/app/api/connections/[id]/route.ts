import { NextRequest, NextResponse } from "next/server";
import { Types } from "mongoose";
import { getSessionUserId } from "@/lib/auth";
import { connectDB } from "@/lib/mongodb";
import { Asset, Connection, Generation } from "@/models";
import { jsonError } from "@/lib/http";

export const runtime = "nodejs";
type Context = { params: Promise<{ id: string }> };

export async function PATCH(request: NextRequest, context: Context) {
  const userId = await getSessionUserId();
  if (!userId) return jsonError("Authentication required", 401);
  const { id } = await context.params;
  const body = await request.json().catch(() => ({}));
  await connectDB();
  const item = await Connection.findOne({ _id: id, userId });
  if (!item) return jsonError("Connection not found", 404);
  if (body.action === "activate") {
    await Connection.updateMany({ userId, provider: item.provider }, { $set: { active: false, isDefault: false } });
    item.active = true; item.isDefault = true; item.enabled = true;
  } else if (body.action === "disable") {
    item.active = false; item.enabled = false;
  } else if (body.action === "default") {
    await Connection.updateMany({ userId, provider: item.provider }, { $set: { isDefault: false } });
    item.isDefault = true;
  } else if (body.action === "rename" && typeof body.label === "string") {
    item.label = body.label.slice(0, 60);
  } else {
    return jsonError("Unsupported connection action", 400);
  }
  await item.save();
  return NextResponse.json({ ok: true, id: String(item._id), active: item.active, isDefault: item.isDefault, enabled: item.enabled, label: item.label });
}

export async function DELETE(_request: NextRequest, context: Context) {
  const userId = await getSessionUserId();
  if (!userId) return jsonError("Authentication required", 401);
  const { id } = await context.params;
  if (!Types.ObjectId.isValid(id)) return jsonError("Invalid record ID", 400);
  await connectDB();
  const item = await Connection.findOne({ _id: id, userId });
  if (!item) return jsonError("Connection not found", 404);
  const pending = await Generation.countDocuments({ userId, connectionId: id, status: { $in: ["queued", "running"] } });
  if (pending > 0) return jsonError("This key is still attached to an unfinished generation. Wait for the task to finish before deleting it.", 409);
  if (item.provider === "yourimageshare") {
    const storedAssets = await Asset.countDocuments({ userId, storageConnectionId: id });
    if (storedAssets > 0) return jsonError(`This key owns ${storedAssets} media records. Delete or migrate those assets before removing the connection.`, 409);
  }
  await item.deleteOne();
  return NextResponse.json({ ok: true });
}
