import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { getSessionUserId } from "@/lib/auth";
import { connectDB } from "@/lib/mongodb";
import { encryptSecret, maskSecret } from "@/lib/crypto";
import { jsonError, requireHttpsUrl } from "@/lib/http";
import { Connection } from "@/models";

export const runtime = "nodejs";
const schema = z.object({
  provider: z.enum(["seedance", "yourimageshare", "custom"]),
  label: z.string().min(2).max(60),
  baseUrl: z.string().url(),
  apiKey: z.string().min(8).max(500),
  makeActive: z.boolean().optional().default(false),
});

function safeConnection(item: any) {
  return {
    id: String(item._id), provider: item.provider, label: item.label, baseUrl: item.baseUrl,
    maskedKey: maskSecret(item.lastFour ? `••••${item.lastFour}` : "••••"), active: item.active,
    isDefault: item.isDefault, enabled: item.enabled, connectionStatus: item.connectionStatus,
    lastTestedAt: item.lastTestedAt,
  };
}

export async function GET() {
  const userId = await getSessionUserId();
  if (!userId) return jsonError("Authentication required", 401);
  await connectDB();
  const items = await Connection.find({ userId }).sort({ provider: 1, createdAt: -1 }).lean();
  return NextResponse.json({ connections: items.map(safeConnection) });
}

export async function POST(request: NextRequest) {
  const userId = await getSessionUserId();
  if (!userId) return jsonError("Authentication required", 401);
  try {
    const input = schema.parse(await request.json());
    const baseUrl = requireHttpsUrl(input.baseUrl);
    const parsedBase = new URL(baseUrl);
    if (input.provider === "seedance" && (parsedBase.hostname !== "open.fast-api.org" || parsedBase.pathname !== "/")) throw new Error("The documented Seedance adapter must use https://open.fast-api.org");
    if (input.provider === "yourimageshare" && (parsedBase.hostname !== "yourimageshare.com" || parsedBase.pathname.replace(/\/$/, "") !== "/api")) throw new Error("YourImageShare must use https://yourimageshare.com/api");
    await connectDB();
    const secret = encryptSecret(input.apiKey);
    const active = input.makeActive;
    if (active) await Connection.updateMany({ userId, provider: input.provider }, { $set: { active: false, isDefault: false } });
    const item = await Connection.create({
      userId, provider: input.provider, label: input.label.trim(), baseUrl, secret,
      lastFour: input.apiKey.slice(-4), active, isDefault: active, enabled: true,
      connectionStatus: "untested",
    });
    return NextResponse.json({ connection: safeConnection(item) }, { status: 201 });
  } catch (error) {
    return jsonError(error instanceof Error ? error.message : "Could not save connection", 400);
  }
}
