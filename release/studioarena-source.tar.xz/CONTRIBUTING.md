# Contributing

Thanks for helping improve StudioArena.

## Local setup

1. Use Node.js 22 and MongoDB.
2. Copy `.env.example` to `.env` and fill the server-side secrets.
3. Run `npm install`, `npm run smoke`, `npm run typecheck`, and `npm run build`.
4. Create a focused branch from `main` and keep credentials out of commits and issue text.

## Provider adapters

A new generation provider should implement the same lifecycle as Seedance: validate model capabilities, submit an asynchronous task, query status, normalize the final media URL, and expose provider errors without returning credentials. Do not assume every API supports the same options.

## Media storage rule

Never place image/video bytes, base64 payloads, or GridFS chunks in MongoDB. Store media through the approved external media provider and persist only its identifiers, stable URLs and metadata. Do not put API keys in client code or `NEXT_PUBLIC_` variables.

## Pull requests

Include a concise summary, test results, data-model changes and any new environment variables. Do not include real API keys or private media URLs in screenshots, commits, logs or test fixtures.
